//
//  AppDelegate.m
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "AppDelegate.h"
#import "SplashScreen.h"

@interface AppDelegate ()

@end

@implementation AppDelegate
@synthesize objNavigationController;
@synthesize CartItemData;
@synthesize sk;
@synthesize appColor;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    /*
    NSMutableDictionary *dict1=[[NSMutableDictionary alloc] init];
    [dict1 setObject:@"Darshan" forKey:@"Check"];
    [dict1 setObject:@"Testing" forKey:@"Value"];
    
    NSMutableDictionary *dict2=[[NSMutableDictionary alloc] init];
    [dict2 setObject:@"Dhaiyur" forKey:@"Check"];
    [dict2 setObject:@"Testing" forKey:@"Value"];
    
    NSMutableDictionary *dict3=[[NSMutableDictionary alloc] init];
    [dict3 setObject:@"Pratik" forKey:@"Check"];
    [dict3 setObject:@"Testing" forKey:@"Value"];
    
    NSMutableDictionary *dict4=[[NSMutableDictionary alloc] init];
    [dict4 setObject:@"Jigar" forKey:@"Check"];
    [dict4 setObject:@"Testing" forKey:@"Value"];
    
    NSMutableArray *array =
    [NSMutableArray arrayWithObjects:dict1, dict2, dict3, dict4, nil];
    
    NSPredicate *sPredicate = [NSPredicate predicateWithFormat:@"SELF contains[c] 'Darshan'"];
    NSArray *beginWithB = [array filteredArrayUsingPredicate:sPredicate];
    NSLog(@"beginwithB = %@",beginWithB);
    
     */
     
    if ([UserDefaults objectForKey:@"app_color"]!=nil)
    {
        NSData *colorData = [UserDefaults objectForKey:@"app_color"];
        appColor = [NSKeyedUnarchiver unarchiveObjectWithData:colorData];
    }
    else
    {
        appColor=RGBA(127, 0, 127, 1.0);
    }
    
    sk = [[SKDatabase alloc] init];
    NSString *db = @"Restaurant.sqlite";
    sk = [sk initWithDynamicFile:db];
    
    [GlobalSync sharedData];
    _globalSync=[[GlobalSync alloc] init];
    
    SplashScreen *objSplashScreen = [[SplashScreen alloc] initWithNibName:@"SplashScreen" bundle:nil];
    
    objNavigationController = [[UINavigationController alloc] initWithRootViewController:objSplashScreen];
    self.window.rootViewController = objNavigationController;
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
