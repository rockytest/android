//
//  SplashScreen.m
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "SplashScreen.h"
#import "LoginViewController.h"

@interface SplashScreen ()

@end

@implementation SplashScreen

- (void)viewDidLoad {
    
    self.view.backgroundColor=app_delegate.appColor;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = true;
}

-(void)viewDidAppear:(BOOL)animated
{
    [self performSelector:@selector(goToLogin) withObject:nil afterDelay:3.0];
}

-(void)goToLogin
{
    LoginViewController *objLoginViewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    [self.navigationController pushViewController:objLoginViewController animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
