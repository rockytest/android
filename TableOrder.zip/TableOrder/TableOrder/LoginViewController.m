//
//  LoginViewController.m
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "LoginViewController.h"
#import "CategoriesDetailViewController.h"
#import "CategoriesViewController.h"
#import "MainRoomViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    txtPassword.text=@"1111";
    
    // allocate and initialize progress bar
    HUD = [[MBProgressHUD alloc] initWithFrame:CGRectMake(kScreenHeight/2 - 15, kScreenWidth/2 - 15, 30, 30)];
    [self.view addSubview:HUD];
    
    _imgBG.image = [_imgBG.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    [_imgBG setTintColor:app_delegate.appColor];
}

- (IBAction)isLoginClicked:(id)sender
{
    @try {
        if ([txtPassword.text length] == 0)
        {
            [self.view makeToast:@"Please enter the password" duration:kAlertDuration position:CSToastPositionBottom];
        }
        else
        {
            // start activity indicator
            [HUD show:YES];
            
            // set the delegate
            _globalSync.delegate = self;
            [_globalSync performSelector:@selector(loginMethod:) withObject:@{@"password":txtPassword.text} afterDelay:0.1];
        }
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

#pragma mark-
#pragma mark- Login API Response
-(void)loginData :(NSDictionary *)aLoginDict error:(NSError *)aError
{
    if ([[aLoginDict objectForKey:@"Success"]isEqualToString:@"True"])
    {
        [UserDefaults setObject:[aLoginDict objectForKey:@"EmployeeId"] forKey:@"userid"];
        [UserDefaults setObject:[aLoginDict objectForKey:@"PriceListId"] forKey:@"PriceListId"];
        [UserDefaults synchronize];
        
        [self.view makeToast:kAlertSuccess duration:kAlertDuration position:CSToastPositionBottom];
        MainRoomViewController *objMainRoomViewController = [[MainRoomViewController alloc] initWithNibName:@"MainRoomViewController" bundle:nil];
        [self.navigationController pushViewController:objMainRoomViewController animated:YES];
    }
    else
    {
        [self.view makeToast:@"Please enter the right password" duration:kAlertDuration position:CSToastPositionBottom];
    }
    
    // stop activity indicator
    [HUD hide:YES afterDelay:1.0];
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
