//
//  Constants.h
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.

#pragma once

#import "GlobalSync.h"
#import <Foundation/Foundation.h>

#import "AppDelegate.h"
#import <AFNetworking/AFNetworking.h>
#import "UIView+Toast.h"

//#import "GlobalGDXData.h"
//#import "GDXSync.h"
//#import <MBProgressHUD/MBProgressHUD.h>

//@class GlobalGDXData;
//@class GDXSync;

#ifndef GameDayXtra_Constants_h
#define GameDayXtra_Constants_h

// delegate
#define app_delegate ((AppDelegate *)[[UIApplication sharedApplication] delegate])
#define UserDefaults  [NSUserDefaults standardUserDefaults]



#define NULLTOEMPTY(obj) ((obj) ? (obj) : @"")

#define QUSTIONMARKNULL(obj) ((obj) ? (obj) : @"?")// For Adjust Bet View

#define NULL_TO_NIL(obj) ({ __typeof__ (obj) __obj = (obj); __obj == [NSNull null] ? nil : obj; })

#define iPad ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad))
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define IS_OS_7    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
#define IS_IPHONE_4 ([[UIScreen mainScreen] bounds].size.height == 480.0)
#define IS_IPHONE_5 ([[UIScreen mainScreen] bounds].size.height == 568.0)
#define IS_IPHONE_6 ([[UIScreen mainScreen] bounds].size.height == 667.0)
#define IS_IPHONE_6PLUS ([[UIScreen mainScreen] nativeScale] == 3.0f)
#define IS_IPHONE_6_PLUS ([[UIScreen mainScreen] bounds].size.height == 736.0)
#define IS_RETINA ([[UIScreen mainScreen] scale] == 2.0)
#define IS_RETINA_DISPLAY ([[UIScreen mainScreen] respondsToSelector:@selector(displayLinkWithTarget:selector:)] && ([UIScreen mainScreen].scale == 2.0))
#define IS_PORTRAIT                 UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])
#define IS_LANDSCAPE                UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])


// Fonts

#define kfontLight(v) [UIFont fontWithName:@"Montserrat-Light" size:v]
#define kfontBold(v) [UIFont fontWithName:@"AvenirNext-Bold" size:v]
#define kfontSemibold(v) [UIFont fontWithName:@"AvenirNext-DemiBold" size:v]
#define kfontSimple(v) [UIFont fontWithName:@"AvenirNext-Regular" size:v]


#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight [[UIScreen mainScreen] bounds].size.height

// Trim String
#define TRIM(string) [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]
#define SpaceRemover(string) [string stringByReplacingOccurrencesOfString:@"\n" withString:@""]
// Status Code
#define kSuccessStatus          200



// KeyBoard Offset

#define kOFFSET_FOR_KEYBOARD    130.0;
#define HIDE_KEYBOARD [[[UIApplication sharedApplication] keyWindow] endEditing:YES];

// Web-Services

// Main URL
#define kAPIBASE_URL              @"http://restaurantposservice.rlogical.com/REST_MOBILE_SVC.svc/"

//Alpha Version URL
#define kAPIBASE_ALPHA            @"http://restaurantposservice.rlogical.com/REST_MOBILE_SVC.svc/"


// User
#define kAPILogin                 @"Login"
#define kAPIFBLogin               @"fblogin"
#define kAPIRegister              @"CustomerRegistration"
#define kAPIForgotPassword        @"resetpassword/forgot"


// Get Categories
#define kAPIGetCategories         @"Get_Category"

// Get Products
#define kAPIGetProducts           @"Get_Products"

// Get Rooms
#define kAPIGetRoom               @"Get_Room_Tables"

// Delete Transaction
#define kAPIDeleteTransaction     @"Delete_Transaction"

// Get Book Table
#define kAPITransactionDetail     @"GetTransactionDetail"

// Checkout
#define kAPICheckout              @"SaveTransaction"

// Color

#define kColorWhite               [UIColor whiteColor]
#define kColorBlack               [UIColor blackColor]
#define kColorClear               [UIColor clearColor]
#define kColorLightGray           [UIColor lightGrayColor]
#define kColorDarkGray            [UIColor darkGrayColor]
#define RGBA(r,g,b,a)             [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:a]
#define kColorCell                [UIColor colorWithRed:195.0/255.0 green:200.0/255.0 blue:212.0/255.0 alpha:1.0]
#define kColorApp                 [UIColor colorWithRed:130.0/255.0 green:180.0/255.0 blue:84.0/255.0 alpha:1.0]

// Messages
#define kColorMyMessageCell       [UIColor colorWithRed:51.0/255.0 green:153.0/255.0 blue:230.0/255.0 alpha:1.0]



// Alerts
#define kAlertSuccess                     @"Success"
#define kAlertError                       @"Error"
#define kAlertFailed                      @"Failed"
#define kAlertPasswordsMatch              @"Passwords don't match !!"
#define kAlertEmailValid                  @"Email is not valid"
#define kAlertAllFieldValid               @"All fields required"
#define kAlertNotLogin                    @"First login to view order"
#define kAlertEmptyField                  @"Please enter blank fields"
#define kAlertDuration                    3.0

// My Message
#define kAlertEmptyMessage                @"Please add message for your friend !"
#define kAlertEmptyFriendId               @"Please add any friend email id !"
#define kAlertSendMessageSuccessfully     @"Your message successfully sent"
#define kAlertSaveBetError                @"Save bet error"



//// GlobalGDXData Variable
//
#pragma mark - Define Variable -


extern GlobalSync *_globalSync;



#endif
