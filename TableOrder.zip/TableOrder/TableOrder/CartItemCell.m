//
//  CartItemCell.m
//  TableOrder
//
//  Created by Macmini on 15/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "CartItemCell.h"

@implementation CartItemCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
