//
//  LoginViewController.h
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController<GlobalApiDelegate,UISplitViewControllerDelegate>
{
    IBOutlet UITextField *txtPassword;
    // Progress HUD
    MBProgressHUD *HUD;
}

@property (strong, nonatomic) UIWindow *window;

- (IBAction)isLoginClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *imgBG;

@end
