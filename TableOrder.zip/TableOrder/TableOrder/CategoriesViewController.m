//
//  CategoriesViewController.m
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "CategoriesViewController.h"
#import "CategoriesTableViewCell.h"
#import "ClubCollectionViewCell.h"
#import "CartViewController.h"
#import "ThemeViewController.h"

@interface CategoriesViewController ()

@end

@implementation CategoriesViewController

- (void)viewDidLoad {
    
    
    dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"MM/dd/yyyy"];
    [dateFormat setTimeZone:[NSTimeZone systemTimeZone]];
    
    TimeFormat = [[NSDateFormatter alloc] init];
    [TimeFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
    [TimeFormat setTimeZone:[NSTimeZone systemTimeZone]];
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    intRow = 0;
}

-(void)viewWillAppear:(BOOL)animated
{
    self.view.backgroundColor=app_delegate.appColor;
    
    _lblCategoryHeader.backgroundColor=app_delegate.appColor;
    _lblDoller.backgroundColor=app_delegate.appColor;
    
    
    [self getCartData]; // This is for get cart data
    
    [self ShowLastCartItem]; // For Display last selected product
    
    tblViewCategoryList.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    if ([tblViewCategoryList respondsToSelector:@selector(setSeparatorInset:)])
    {
        [tblViewCategoryList setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // allocate and initialize the array to store the categories list
    listArray = [[NSMutableArray alloc] init];
    
    // allocate and initialize the array to store the categories id
    categoryIdArray = [[NSMutableArray alloc] init];
    
    // allocate and initialize the array to store the categories photo path
    imgArray = [[NSMutableArray alloc] init];
    
    // allocate and initialize progress bar
    HUD = [[MBProgressHUD alloc] initWithFrame:CGRectMake(kScreenHeight/2 - 15, kScreenWidth/2 - 15, 30, 30)];
    [self.view addSubview:HUD];
    
    _lblHeader.text=[NSString stringWithFormat:@"MAIN ROOM - Table %@",[UserDefaults objectForKey:@"TableNo"]];
    
    [self.collectionView registerClass:[ClubCollectionViewCell class] forCellWithReuseIdentifier:@"ClubCollectionViewCell"];
    
    
    @try {
        NSData *myDecodedObject = [UserDefaults objectForKey:@"CategoryListArray"];
        NSArray *decodedArrayCategory =[NSKeyedUnarchiver unarchiveObjectWithData: myDecodedObject];
        if ([decodedArrayCategory count] != 0) {
            categoryArray=[decodedArrayCategory mutableCopy];
            [tblViewCategoryList reloadData];
        }
    } @catch (NSException *exception) {
        
    }
    
    
    @try {
        NSData *myDecodedObjectProduct = [UserDefaults objectForKey:@"ProductListArray"];
        NSArray *decodedArray =[NSKeyedUnarchiver unarchiveObjectWithData: myDecodedObjectProduct];
        if ([decodedArray count] != 0) {
            allProductArray=[decodedArray mutableCopy];
            
            productArray =[[NSMutableArray alloc] init];
            for (int i = 0; i < [allProductArray count]; i++) {
                if ([[[allProductArray objectAtIndex:i] objectForKey:@"CategoryId"] intValue] == 1) {
                    [productArray addObject:[allProductArray objectAtIndex:i]];
                }
            }
            [_collectionView reloadData];
        }
    } @catch (NSException *exception) {
        
    } @finally {
        [_collectionView reloadData];
    }
}

-(void)getCategoriesList
{
    // start activity indicator
    [HUD show:YES];
    
    // set the delegate
    _globalSync.delegate = self;
    [_globalSync performSelector:@selector(getCategoriesMethod:) withObject:@{@"CategoryId":@"0"} afterDelay:0.1];
}


#pragma mark-
#pragma mark- Get Category API Response
-(void)getCategoriesData :(NSDictionary *)aGetCategoriesDict error:(NSError *)aError
{
    NSLog(@"category list:-->> %@",aGetCategoriesDict);
    
    @try {
        
        NSMutableArray *allCategoryArray=(NSMutableArray *)aGetCategoriesDict;
        NSData *myEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:allCategoryArray];
        [UserDefaults setObject:myEncodedObject forKey:[NSString stringWithFormat:@"CategoryListArray"]];
        [UserDefaults synchronize];
        
        categoryArray=allCategoryArray;
    }
    @catch (NSException *exception) {
        
    }
    // reload the table view
    [tblViewCategoryList reloadData];
}

#pragma mark-
#pragma mark- Get Product API Response
-(void)getProductsData :(NSDictionary *)aGetProductsDict error:(NSError *)aError
{
    NSLog(@"%@",aGetProductsDict);
    
    @try {
        
        allProductArray=(NSMutableArray *)aGetProductsDict;
        NSData *myEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:allProductArray];
        [UserDefaults setObject:myEncodedObject forKey:[NSString stringWithFormat:@"ProductListArray"]];
        [UserDefaults synchronize];
        
        productArray =[[NSMutableArray alloc] init];
        for (int i = 0; i < [allProductArray count]; i++) {
            if ([[[allProductArray objectAtIndex:i] objectForKey:@"CategoryId"] intValue] == 1) {
                [productArray addObject:[allProductArray objectAtIndex:i]];
            }
        }
        [_collectionView reloadData];
    }
    @catch (NSException *exception) {
        
    }
    
    // stop activity indicator
    [HUD hide:YES];
}

#pragma mark -
#pragma mark - UICollectionViewwDataSource

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return [productArray count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    // Setup cell identifier
    static NSString *cellIdentifier = @"ClubCollectionViewCell";
    // NSString * cellIdentifier =[NSString stringWithFormat:@"BottomListCollectionViewCell%d",indexPath.row];
    
    ClubCollectionViewCell *cell = (ClubCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    // Return the cell
    return cell;
    
}
- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(ClubCollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    [cell.imgClub sd_setImageWithURL:[NSURL URLWithString:[[productArray objectAtIndex:indexPath.row] objectForKey:@"photopath"]] placeholderImage:nil];
    cell.lblClubName.text=[[productArray objectAtIndex:indexPath.row] objectForKey:@"ItemName"];
    
    [self addBorderToView:2 color:app_delegate.appColor cornerRadius:4 objButton:cell];
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSMutableDictionary *insertDatabaseDict=[[NSMutableDictionary alloc] init];
    NSString *isOffer;
    NSString *isExtra=[[[[productArray objectAtIndex:indexPath.row]objectForKey:@"extraitems"]objectAtIndex:0]objectForKey:@"Success"];
    
    NSString *isComment=[[[[productArray objectAtIndex:indexPath.row]objectForKey:@"itemcomments"]objectAtIndex:0]objectForKey:@"Success"];
    
    isOffer=[[[[productArray objectAtIndex:indexPath.row]objectForKey:@"itemoffers"]objectAtIndex:0]objectForKey:@"Success"];
    
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[productArray objectAtIndex:indexPath.row] objectForKey:@"CategoryId"])] forKey:@"CategoryId"];
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[productArray objectAtIndex:indexPath.row] objectForKey:@"ItemId"])] forKey:@"ItemId"];
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[productArray objectAtIndex:indexPath.row] objectForKey:@"ItemName"])] forKey:@"ItemName"];
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[productArray objectAtIndex:indexPath.row] objectForKey:@"ItemSaleFormatId"])] forKey:@"ItemSaleFormatId"];
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[productArray objectAtIndex:indexPath.row] objectForKey:@"Price"])] forKey:@"Price"];
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"1"] forKey:@"qty"];
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"0"] forKey:@"discount"];
    
    if([isExtra isEqualToString:@"True"])
    {
        [insertDatabaseDict setObject:[NSString stringWithFormat:@"1"] forKey:@"isExtra"];
    }
    else
    {
        [insertDatabaseDict setObject:[NSString stringWithFormat:@"0"] forKey:@"isExtra"];
    }
    
    [insertDatabaseDict setObject:[UserDefaults objectForKey:@"TableNo"] forKey:@"Tableno"];
    [insertDatabaseDict setObject:[UserDefaults objectForKey:@"RoomId"] forKey:@"roomid"];
    [insertDatabaseDict setObject:[UserDefaults objectForKey:@"userid"] forKey:@"employeeid"];
    [insertDatabaseDict setObject:@"0" forKey:@"freeqty"];
    [insertDatabaseDict setObject:@"0" forKey:@"isOffer"];
    [insertDatabaseDict setObject:[UserDefaults objectForKey:@"TicketId"] forKey:@"Ticketid"];
    
    
    NSString*strqty;
    NSString*strprice;
    NSString*strDiscount;
    strqty=[NSString stringWithFormat:@"1"];
    strprice=[NSString stringWithFormat:@"%@",NULL_TO_NIL([[productArray objectAtIndex:indexPath.row] objectForKey:@"Price"])];
    strDiscount=[NSString stringWithFormat:@"0"];
    
    NSString *Total=[NSString stringWithFormat:@"%f",[strqty floatValue]*[strprice floatValue]];
    
    NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[strDiscount floatValue]];
    
    NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
    
    NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f",[Total floatValue]-[finalTotal floatValue]];
    
    [insertDatabaseDict setObject:fullFinalTotal forKey:@"subtotal"];
    
    NSString *CommentString=@"";
    NSString *isCommentString=@"";
    if([isComment isEqualToString:@"True"])
    {
        NSArray *commentArray;
        
        commentArray=[[productArray objectAtIndex:indexPath.row]objectForKey:@"itemcomments"];
        for (int i=0; i<[commentArray count]; i++)
        {
            CommentString=[CommentString stringByAppendingString:[NSString stringWithFormat:@"%@`",[[commentArray objectAtIndex:i] objectForKey:@"Comment"]]];
            isCommentString=[isCommentString stringByAppendingString:[NSString stringWithFormat:@"False`"]];
        }
        
        [insertDatabaseDict setObject:CommentString forKey:@"commentname"];
        [insertDatabaseDict setObject:isCommentString forKey:@"iscommentAdd"];
    }
    else
    {
        [insertDatabaseDict setObject:@"" forKey:@"commentname"];
        [insertDatabaseDict setObject:@"" forKey:@"iscommentAdd"];
    }
    
    [insertDatabaseDict setObject:@"" forKey:@"Extraname"];
    [insertDatabaseDict setObject:@"0" forKey:@"Promotionid"];
    [insertDatabaseDict setObject:@"0" forKey:@"ExtraRowId"];
    
    [insertDatabaseDict setObject:[NSString stringWithFormat:@"%d",1 + rand() % (9999-1)] forKey:@"RowId"];
    
    [insertDatabaseDict setObject:@"0" forKey:@"Extraitemid"];
    [insertDatabaseDict setObject:@"0" forKey:@"sequence"];
    [insertDatabaseDict setObject:@"0" forKey:@"isextraAdd"];
    [insertDatabaseDict setObject:@"" forKey:@"finalcomment"];
    [insertDatabaseDict setObject:@"0" forKey:@"IsPrint"];
    [app_delegate.sk insertDictionary:insertDatabaseDict forTable:@"AddProduct"];
    
    
    NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
    app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
    
    
    if([isOffer isEqualToString:@"True"])
    {
        offerArray=[[NSMutableArray alloc]init];
        offerArray=[[allProductArray objectAtIndex:indexPath.row] objectForKey:@"itemoffers"];
        NSLog(@"Offer Value%@",offerArray);
        NewofferArray=[[NSMutableArray alloc]init];
        for (int i=0; i<offerArray.count; i++)
        {
            NSDate *startdate = [dateFormat dateFromString:[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"StartDate"]]];
            NSDate *Enddate = [dateFormat dateFromString:[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"EndDate"]]];
            
            NSDate *startTime = [TimeFormat dateFromString:[NSString stringWithFormat:@"%@ %@",[dateFormat stringFromDate:[NSDate date]],[[offerArray objectAtIndex:i]objectForKey:@"StartTime"]]];
            NSDate *EndTime = [TimeFormat dateFromString:[NSString stringWithFormat:@"%@ %@",[dateFormat stringFromDate:[NSDate date]],[[offerArray objectAtIndex:i]objectForKey:@"EndTime"]]];
            
            NSString *IsSunday=[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"IsSunday"]];
            NSString *IsMonday=[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"IsMonday"]];
            NSString *IsTuesday=[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"IsTuesday"]];
            NSString *IsWednesday=[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"IsWednesday"]];
            NSString *IsThursday=[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"IsThursday"]];
            NSString *IsFriday=[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"IsFriday"]];
            NSString *IsSaturday=[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"IsSaturday"]];
            
            if ([[NSString stringWithFormat:@"%@",[[offerArray objectAtIndex:i]objectForKey:@"Success"]] isEqualToString:@"True"])
            {
                if ([self inputDate:[NSDate date] start:startdate end:Enddate] )
                {
                    NSLog(@"Between dates!!!");
                    
                    NSCalendar* cal = [NSCalendar currentCalendar];
                    
                    NSDateComponents* comp = [cal components:kCFCalendarUnitWeekday fromDate:[NSDate date]];
                    
                    NSLog(@"Week Day====>%@",[NSString stringWithFormat:@"%d",(int)[comp weekday]]);
                    
                    if ((int)[comp weekday]==1)
                    {
                        if ([IsSunday isEqualToString:@"1"])
                        {
                            if ([self inputDate:[NSDate date] start:startTime end:EndTime] )
                            {
                                NSLog(@"Between Time!!!");
                                [NewofferArray addObject:[offerArray objectAtIndex:i]];
                            }
                        }
                    }
                    else if ((int)[comp weekday]==2)
                    {
                        if ([IsMonday isEqualToString:@"1"])
                        {
                            if ([self inputDate:[NSDate date] start:startTime end:EndTime] )
                            {
                                NSLog(@"Between Time!!!");
                                [NewofferArray addObject:[offerArray objectAtIndex:i]];
                            }
                        }
                    }
                    else if ((int)[comp weekday]==3)
                    {
                        if ([IsTuesday isEqualToString:@"1"])
                        {
                            if ([self inputDate:[NSDate date] start:startTime end:EndTime] )
                            {
                                NSLog(@"Between Time!!!");
                                [NewofferArray addObject:[offerArray objectAtIndex:i]];
                            }
                        }
                    }
                    else if ((int)[comp weekday]==4)
                    {
                        if ([IsWednesday isEqualToString:@"1"])
                        {
                            if ([self inputDate:[NSDate date] start:startTime end:EndTime] )
                            {
                                NSLog(@"Between Time!!!");
                                [NewofferArray addObject:[offerArray objectAtIndex:i]];
                            }
                        }
                    }
                    else if ((int)[comp weekday]==5)
                    {
                        if ([IsThursday isEqualToString:@"1"])
                        {
                            if ([self inputDate:[NSDate date] start:startTime end:EndTime])
                            {
                                NSLog(@"Between Time!!!");
                                [NewofferArray addObject:[offerArray objectAtIndex:i]];
                            }
                        }
                    }
                    else if ((int)[comp weekday]==6)
                    {
                        if ([IsFriday isEqualToString:@"1"])
                        {
                            if ([self inputDate:[NSDate date] start:startTime end:EndTime] )
                            {
                                NSLog(@"Between Time!!!");
                                [NewofferArray addObject:[offerArray objectAtIndex:i]];
                            }
                        }
                    }
                    else if ((int)[comp weekday]==7)
                    {
                        if ([IsSaturday isEqualToString:@"1"])
                        {
                            if ([self inputDate:[NSDate date] start:startTime end:EndTime] )
                            {
                                NSLog(@"Between Time!!!");
                                [NewofferArray addObject:[offerArray objectAtIndex:i]];
                            }
                        }
                    }
                }
                else
                {
                    NSLog(@"Not Between dates!!!");
                }
            }
        }
        
        NSLog(@"New Offer Array:=>%@",NewofferArray);
        
        isOfferClicked=TRUE;
        
        
        MainOfferView_potraiti.frame=CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height);
        [self.view addSubview:MainOfferView_potraiti];
        [self setOfferItemPotraitScroll];
    }
    
    [self ShowLastCartItem];
}

#pragma mark Offer View
-(void)setOfferItemPotraitScroll
{
    
    imgSpecialOffer_potraiti.frame=CGRectMake(370, 250, 70, 70);
    innerOfferView_potraiti.frame=CGRectMake(245.0, 300.0, 320, 400);
    
    [OfferScroll_potraiti removeFromSuperview];
    OfferScroll_potraiti=[[UIScrollView alloc]init];
    OfferScroll_potraiti.frame=CGRectMake(0, 94, 320, 255);
    [innerOfferView_potraiti addSubview:OfferScroll_potraiti];
    UILabel *lblbgwhite;
    UILabel *lblOfferName;
    UILabel *lbllansapepatty;
    UILabel *lblpotraitpatty;
    UILabel *lblOfferDescription;
    UIButton *btnOffer;
    [lblbgwhite removeFromSuperview];
    [lblOfferName removeFromSuperview];
    [lbllansapepatty removeFromSuperview];
    [lblpotraitpatty removeFromSuperview];
    [lblOfferDescription removeFromSuperview];
    [btnOffer removeFromSuperview];
    
    int x=0;
    int y=0;
    
    UILabel *firstpatty=[[UILabel alloc]init];
    firstpatty.frame=CGRectMake(0, y, 300, 1);
    [firstpatty setBackgroundColor:[UIColor lightGrayColor]];
    
    for(int i=0;i<[NewofferArray count];i++)
    {
        lblbgwhite=[[UILabel alloc]init];
        lblbgwhite.frame=CGRectMake(x+0, y+0, 320, 39);
        [lblbgwhite setBackgroundColor:[UIColor whiteColor]];
        [OfferScroll_potraiti addSubview:lblbgwhite];
        
        lblOfferName=[[UILabel alloc]init];
        lblOfferName.frame=CGRectMake(x+5, y+8, 159, 25);
        
        [lblOfferName setFont:[UIFont fontWithName:@"Helvetica Neue" size:15]];
        lblOfferName.text=[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:i]objectForKey:@"PromotionOffer"]];
        lblOfferName.textColor=[UIColor blackColor];
        
        [OfferScroll_potraiti addSubview:lblOfferName];
        
        lblpotraitpatty=[[UILabel alloc]init];
        lblpotraitpatty.frame=CGRectMake(x+160, y, 1, 39);
        [lblpotraitpatty setBackgroundColor:[UIColor lightGrayColor]];
        [OfferScroll_potraiti addSubview:lblpotraitpatty];
        lblOfferDescription=[[UILabel alloc]init];
        lblOfferDescription.frame=CGRectMake(x+163, y+8, 155, 25);
        
        [lblOfferDescription setFont:[UIFont fontWithName:@"Helvetica Neue" size:15]];
        lblOfferDescription.text=[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:i]objectForKey:@"PromotionDesceiption"]];
        lblOfferDescription.textColor=[UIColor blackColor];
        
        [OfferScroll_potraiti addSubview:lblOfferDescription];
        lbllansapepatty=[[UILabel alloc]init];
        lbllansapepatty.frame=CGRectMake(0, y+39, 320, 1);
        [lbllansapepatty setBackgroundColor:[UIColor lightGrayColor]];
        [OfferScroll_potraiti addSubview:lbllansapepatty];
        btnOffer=[UIButton buttonWithType:UIButtonTypeCustom];
        btnOffer.frame=CGRectMake(x+0, y+0, 320, 39);
        btnOffer.tag=i;
        [btnOffer addTarget:self action:@selector(btnofferClick:) forControlEvents:UIControlEventTouchUpInside];
        [OfferScroll_potraiti addSubview:btnOffer];
        y=y+40;
    }
    OfferScroll_potraiti.contentSize=CGSizeMake(320, y);
}

-(void)btnofferClick:(id)sender
{
    NSLog(@"Offer Tag:=>%d",(int)[sender tag]);
    
    NSLog(@"New Offer:=>%@",[NewofferArray objectAtIndex:[sender tag]]);
    
    if ([[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"PromotionType"]] isEqualToString:@"1"])
    {
        NSMutableDictionary *UpdataDictForFav=[[NSMutableDictionary alloc] init];
        [UpdataDictForFav setObject:[[allProductArray objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"CategoryId"] forKey:@"CategoryId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemId"] forKey:@"ItemId"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemName"]] forKey:@"ItemName"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemSaleFormatId"] forKey:@"ItemSaleFormatId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Price"] forKey:@"Price"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Tableno"] forKey:@"Tableno"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"Discount"]] forKey:@"discount"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"employeeid"] forKey:@"employeeid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"] forKey:@"id"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isExtra"] forKey:@"isExtra"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"qty"] forKey:@"qty"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"roomid"] forKey:@"roomid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"freeqty"] forKey:@"freeqty"];
        [UpdataDictForFav setObject:@"1" forKey:@"isOffer"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Ticketid"] forKey:@"Ticketid"];
        
        NSString*strqty;
        NSString*strprice;
        NSString*strDiscount;
        
        strqty=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"qty"]];
        strprice=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Price"]];
        strDiscount=[NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"Discount"]]];
        
        NSString *Total=[NSString stringWithFormat:@"%f",[strqty floatValue]*[strprice floatValue]];
        NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[strDiscount floatValue]];
        NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
        NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f",[Total floatValue]-[finalTotal floatValue]];
        
        [UpdataDictForFav setObject:fullFinalTotal forKey:@"subtotal"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"commentname"] forKey:@"commentname"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraname"] forKey:@"Extraname"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:(int)[sender tag]] objectForKey:@"PromotionId"]] forKey:@"Promotionid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ExtraRowId"] forKey:@"ExtraRowId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"RowId"] forKey:@"RowId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraitemid"] forKey:@"Extraitemid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"sequence"] forKey:@"sequence"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isextraAdd"] forKey:@"isextraAdd"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"iscommentAdd"] forKey:@"iscommentAdd"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"finalcomment"] forKey:@"finalcomment"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"IsPrint"] forKey:@"IsPrint"];
        
        
        NSString *wherestr=[NSString stringWithFormat:@"roomid=%@ and Tableno=%@ and id=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"],[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"]];
        
        [app_delegate.sk updateDictionary:UpdataDictForFav forTable:@"AddProduct" where:wherestr];
        
        NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
        
        app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
        
        [self Removeoffer];
    }
    else if ([[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"PromotionType"]] isEqualToString:@"4"])
    {
        NSLog(@"Special Offer Price:=>%@",[NSString stringWithFormat:@"%@",[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionprice"] objectForKey:@"itemprice"]]);
        
        NSMutableDictionary *UpdataDictForFav=[[NSMutableDictionary alloc] init];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"CategoryId"] forKey:@"CategoryId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemId"] forKey:@"ItemId"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemName"]] forKey:@"ItemName"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemSaleFormatId"] forKey:@"ItemSaleFormatId"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionprice"] objectForKey:@"itemprice"]] forKey:@"Price"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Tableno"] forKey:@"Tableno"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"discount"] forKey:@"discount"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"employeeid"] forKey:@"employeeid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"] forKey:@"id"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isExtra"] forKey:@"isExtra"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"qty"] forKey:@"qty"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"roomid"] forKey:@"roomid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"freeqty"] forKey:@"freeqty"];
        [UpdataDictForFav setObject:@"1" forKey:@"isOffer"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Ticketid"] forKey:@"Ticketid"];
        
        NSString*strqty;
        NSString*strprice;
        NSString*strDiscount;
        
        strqty=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"qty"]];
        strprice=[NSString stringWithFormat:@"%@",[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionprice"] objectForKey:@"itemprice"]];
        strDiscount=[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"discount"];
        
        NSString *Total=[NSString stringWithFormat:@"%f",[strqty floatValue]*[strprice floatValue]];
        NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[strDiscount floatValue]];
        NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
        NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f",[Total floatValue]-[finalTotal floatValue]];
        
        [UpdataDictForFav setObject:fullFinalTotal forKey:@"subtotal"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"commentname"] forKey:@"commentname"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraname"] forKey:@"Extraname"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"PromotionId"]]] forKey:@"Promotionid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ExtraRowId"] forKey:@"ExtraRowId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"RowId"] forKey:@"RowId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraitemid"] forKey:@"Extraitemid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"sequence"] forKey:@"sequence"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isextraAdd"] forKey:@"isextraAdd"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"iscommentAdd"] forKey:@"iscommentAdd"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"finalcomment"] forKey:@"finalcomment"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"IsPrint"] forKey:@"IsPrint"];
        
        
        NSString *wherestr=[NSString stringWithFormat:@"roomid=%@ and Tableno=%@ and id=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"],[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"]];
        
        [app_delegate.sk updateDictionary:UpdataDictForFav forTable:@"AddProduct" where:wherestr];
        
        NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
        
        app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
        
        [self Removeoffer];
    }
    else if ([[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"PromotionType"]] isEqualToString:@"3"])
    {
        [self Removeoffer];
        
        OfferTag=(int)[sender tag];
        
        isvolumeOfferClicked=TRUE;
        
        MainVolumeOfferView_potrait.frame=CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height);
        [self.view addSubview:MainVolumeOfferView_potrait];
        [self setVolumeOfferItemPotraitScroll_ipad];
        
    }
    else if ([[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"PromotionType"]] isEqualToString:@"2"])
    {
        NSLog(@"3 bye get 1 Free offer :=>%@",[NewofferArray objectAtIndex:[sender tag]]);
        
        NSLog(@"Purchase Qty:%@",[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionqty"] objectForKey:@"Purchase_Qty"]);
        
        NSLog(@"Free Qty:%@",[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionqty"] objectForKey:@"free_Qty"]);
        
        NSMutableDictionary *UpdataDictForFav=[[NSMutableDictionary alloc] init];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"CategoryId"] forKey:@"CategoryId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemId"] forKey:@"ItemId"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemName"]] forKey:@"ItemName"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemSaleFormatId"] forKey:@"ItemSaleFormatId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Price"] forKey:@"Price"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Tableno"] forKey:@"Tableno"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"discount"] forKey:@"discount"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"employeeid"] forKey:@"employeeid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"] forKey:@"id"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isExtra"] forKey:@"isExtra"];
        [UpdataDictForFav setObject:[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionqty"] objectForKey:@"Purchase_Qty"] forKey:@"qty"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"roomid"] forKey:@"roomid"];
        [UpdataDictForFav setObject:[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionqty"] objectForKey:@"free_Qty"] forKey:@"freeqty"];
        [UpdataDictForFav setObject:@"1" forKey:@"isOffer"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Ticketid"] forKey:@"Ticketid"];
        
        
        NSString*strqty;
        NSString*strprice;
        NSString*strDiscount;
        
        strqty=[NSString stringWithFormat:@"%@",[[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"objpromotionqty"] objectForKey:@"Purchase_Qty"]];
        strprice=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Price"]];
        strDiscount=[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"discount"];
        
        NSString *Total=[NSString stringWithFormat:@"%f",[strqty floatValue]*[strprice floatValue]];
        NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[strDiscount floatValue]];
        NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
        NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f",[Total floatValue]-[finalTotal floatValue]];
        
        [UpdataDictForFav setObject:fullFinalTotal forKey:@"subtotal"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"commentname"] forKey:@"commentname"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraname"] forKey:@"Extraname"];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"%@",[[NewofferArray objectAtIndex:[sender tag]] objectForKey:@"PromotionId"]]] forKey:@"Promotionid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ExtraRowId"] forKey:@"ExtraRowId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"RowId"] forKey:@"RowId"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraitemid"] forKey:@"Extraitemid"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"sequence"] forKey:@"sequence"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isextraAdd"] forKey:@"isextraAdd"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"iscommentAdd"] forKey:@"iscommentAdd"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"finalcomment"] forKey:@"finalcomment"];
        [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"IsPrint"] forKey:@"IsPrint"];
        
        NSString *wherestr=[NSString stringWithFormat:@"roomid=%@ and Tableno=%@ and id=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"],[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"]];
        
        [app_delegate.sk updateDictionary:UpdataDictForFav forTable:@"AddProduct" where:wherestr];
        
        NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
        
        app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
        
        [self Removeoffer];
    }
    
    [self ShowLastCartItem];
}

-(void)setVolumeOfferItemPotraitScroll_ipad
{
    NSLog(@"%@",[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"]);
    
    innerVolumeOfferView_potrait.frame=CGRectMake(250,400, 320,256);
    
    
    [VolumeOfferScroll_potrait removeFromSuperview];
    VolumeOfferScroll_potrait=[[UIScrollView alloc]init];
    
    VolumeOfferScroll_potrait.frame=CGRectMake(0, 52, 320, 153);
    
    [innerVolumeOfferView_potrait addSubview:VolumeOfferScroll_potrait];
    
    UILabel *lblbgwhite;
    UILabel *lblvolumeqty;
    UILabel *lbllansapepatty;
    UILabel *lblpotraitpatty;
    UILabel *lblvolumediscount;
    UIButton *btnOffer;
    
    
    [lblbgwhite removeFromSuperview];
    [lblvolumeqty removeFromSuperview];
    [lbllansapepatty removeFromSuperview];
    [lblpotraitpatty removeFromSuperview];
    [lblvolumediscount removeFromSuperview];
    [btnOffer removeFromSuperview];
    
    int x=0;
    int y=0;
    
    UILabel *firstpatty=[[UILabel alloc]init];
    firstpatty.frame=CGRectMake(0, y, 320, 1);
    [firstpatty setBackgroundColor:[UIColor lightGrayColor]];
    
    for(int i=0;i<(int)[[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"] count];i++)
    {
        lblbgwhite=[[UILabel alloc]init];
        lblbgwhite.frame=CGRectMake(x+0, y+0, 320, 50);
        [lblbgwhite setBackgroundColor:[UIColor whiteColor]];
        [VolumeOfferScroll_potrait addSubview:lblbgwhite];
        
        lblvolumeqty=[[UILabel alloc]init];
        lblvolumeqty.frame=CGRectMake(x+5, y+8, 155, 25);
        lblvolumeqty.textAlignment=NSTextAlignmentCenter;
        [lblvolumeqty setFont:[UIFont fontWithName:@"Helvetica Neue" size:18]];
        lblvolumeqty.text=[NSString stringWithFormat:@"%@",[[[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"] objectAtIndex:i] objectForKey:@"Qty"]];
        lblvolumeqty.textColor=[UIColor blackColor];
        
        [VolumeOfferScroll_potrait addSubview:lblvolumeqty];
        
        lblpotraitpatty=[[UILabel alloc]init];
        lblpotraitpatty.frame=CGRectMake(x+160, y, 1, 50);
        [lblpotraitpatty setBackgroundColor:[UIColor lightGrayColor]];
        [VolumeOfferScroll_potrait addSubview:lblpotraitpatty];
        
        
        lblvolumediscount=[[UILabel alloc]init];
        lblvolumediscount.frame=CGRectMake(x+167, y+8, 155, 25);
        lblvolumediscount.textAlignment=NSTextAlignmentCenter;
        [lblvolumediscount setFont:[UIFont fontWithName:@"Helvetica Neue" size:18]];
        
        NSString *percentagesign=@"%";
        lblvolumediscount.text=[NSString stringWithFormat:@"%@%@",[[[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"] objectAtIndex:i] objectForKey:@"discount"],percentagesign];
        lblvolumediscount.textColor=[UIColor blackColor];
        
        [VolumeOfferScroll_potrait addSubview:lblvolumediscount];
        
        lbllansapepatty=[[UILabel alloc]init];
        lbllansapepatty.frame=CGRectMake(0, y+48, 320, 1);
        [lbllansapepatty setBackgroundColor:[UIColor lightGrayColor]];
        
        [VolumeOfferScroll_potrait addSubview:lbllansapepatty];
        
        btnOffer=[UIButton buttonWithType:UIButtonTypeCustom];
        btnOffer.frame=CGRectMake(x+0, y+0, 320, 39);
        btnOffer.tag=i;
        NSLog(@"btnOffer.tag %d",btnOffer.tag);
        [btnOffer addTarget:self action:@selector(btnVolumeofferClick:) forControlEvents:UIControlEventTouchUpInside];
        [VolumeOfferScroll_potrait addSubview:btnOffer];
        
        y=y+50;
    }
    
    VolumeOfferScroll_potrait.contentSize=CGSizeMake(320, y);
}
-(void)btnVolumeofferClick:(id)sender
{
    
    NSLog(@"Tag:=>%d",(int)[sender tag]);
    NSLog(@"Tag:=>%d",(int)OfferTag);
    
    
    NSMutableDictionary *UpdataDictForFav=[[NSMutableDictionary alloc] init];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"CategoryId"] forKey:@"CategoryId"];
    
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemId"] forKey:@"ItemId"];
    [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemName"]] forKey:@"ItemName"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ItemSaleFormatId"] forKey:@"ItemSaleFormatId"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Price"] forKey:@"Price"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Tableno"] forKey:@"Tableno"];
    [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"] objectAtIndex:[sender tag]] objectForKey:@"discount"]] forKey:@"discount"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"employeeid"] forKey:@"employeeid"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"] forKey:@"id"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isExtra"] forKey:@"isExtra"];
    [UpdataDictForFav setObject:[[[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"] objectAtIndex:[sender tag]] objectForKey:@"Qty"] forKey:@"qty"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"roomid"] forKey:@"roomid"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"freeqty"] forKey:@"freeqty"];
    [UpdataDictForFav setObject:@"1" forKey:@"isOffer"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Ticketid"] forKey:@"Ticketid"];
    
    NSString*strqty;
    NSString*strprice;
    NSString*strDiscount;
    
    strqty=[NSString stringWithFormat:@"%@",[[[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"] objectAtIndex:[sender tag]] objectForKey:@"Qty"]];
    
    strprice=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Price"]];
    
    strDiscount=[NSString stringWithFormat:@"%@",[[[[NewofferArray objectAtIndex:OfferTag]objectForKey:@"objpromotionvolume"] objectAtIndex:[sender tag]] objectForKey:@"discount"]];
    NSString *Total=[NSString stringWithFormat:@"%f",[strqty floatValue]*[strprice floatValue]];
    NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[strDiscount floatValue]];
    NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
    NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f",[Total floatValue]-[finalTotal floatValue]];
    [UpdataDictForFav setObject:fullFinalTotal forKey:@"subtotal"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"commentname"] forKey:@"commentname"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraname"] forKey:@"Extraname"];
    
    [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",[[[[NewofferArray objectAtIndex:OfferTag] objectForKey:@"objpromotionvolume"] objectAtIndex:[sender tag]] objectForKey:@"PromotionId"]] forKey:@"Promotionid"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"ExtraRowId"] forKey:@"ExtraRowId"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"RowId"] forKey:@"RowId"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"Extraitemid"] forKey:@"Extraitemid"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"sequence"] forKey:@"sequence"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"isextraAdd"] forKey:@"isextraAdd"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"iscommentAdd"] forKey:@"iscommentAdd"];
    
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"finalcomment"] forKey:@"finalcomment"];
    
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"IsPrint"] forKey:@"IsPrint"];
    
    
    NSString *wherestr=[NSString stringWithFormat:@"roomid=%@ and Tableno=%@ and id=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"],[[app_delegate.CartItemData objectAtIndex:(int)[app_delegate.CartItemData count]-1] objectForKey:@"id"]];
    [app_delegate.sk updateDictionary:UpdataDictForFav forTable:@"AddProduct" where:wherestr];
    
    NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
    
    app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
    
    NSLog(@"%@",[app_delegate.sk lookupAllForSQL:@"select * from AddProduct"]);
    
    NSLog(@"After :=>Cart Item Data %@",app_delegate.CartItemData);
    
    [self RemovevolumeOffer];
    
    [self ShowLastCartItem];
}

-(void)RemovevolumeOffer
{
    isvolumeOfferClicked=FALSE;
    [MainVolumeOfferView_potrait removeFromSuperview];
}

-(void)Removeoffer
{
    [MainOfferView_potraiti removeFromSuperview];
    [MainVolumeOfferView_potrait removeFromSuperview];
}

-(void)ShowLastCartItem
{
    NSLog(@"%@",app_delegate.CartItemData);
    
    if ([app_delegate.CartItemData count] == 0) {
        _lblCartItemName.text=@"No Product";
        _lblCartItemName.frame=CGRectMake(8, _lblCartItemName.bounds.origin.y, _lblCartItemName.bounds.size.width, 79);
        _lblCartItemQTY.text=@"";
        _lblTotalPrice.text=@"0.00";
        _refBtnCancel.enabled=FALSE;
        return;
    } else {
        _lblCartItemName.frame=CGRectMake(8, _lblCartItemName.bounds.origin.y, _lblCartItemName.bounds.size.width, 36);
    }
    
    if ([[[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1] objectForKey:@"IsPrint"] isEqualToString:@"1"]) {
        _refBtnCancel.enabled=FALSE;
    } else {
        _refBtnCancel.enabled=TRUE;
    }
    
    NSLog(@"%@",[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1]);
    
    _lblCartItemName.text=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1] objectForKey:@"ItemName"]];
    
    _lblCartItemQTY.text=[NSString stringWithFormat:@"%@ X $ %@.00",[[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1] objectForKey:@"qty"],[[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1] objectForKey:@"Price"]];
    _lblTotalPrice.text=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1] objectForKey:@"subtotal"]];
}

-(void)getCartData
{
    NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
    
    app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
}
- (IBAction)btnCancel:(id)sender {
    
    if ([[[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1] objectForKey:@"IsPrint"] intValue] != 1)
    {
        [app_delegate.sk deleteWhere:[NSString stringWithFormat:@"id=%@",[[app_delegate.CartItemData objectAtIndex:[app_delegate.CartItemData count]-1] objectForKey:@"id"]] forTable:@"AddProduct"];
        
        [self getCartData];
        
        [self ShowLastCartItem];
    }
}


// Add border and corner to UIView
-(void)addBorderToView :(float)WidthB color:(UIColor *)borderColor cornerRadius:(float)cornerR objButton :(ClubCollectionViewCell *)cell
{
    cell.layer.borderColor = [borderColor CGColor];
    cell.layer.borderWidth = WidthB;
    cell.layer.cornerRadius = cornerR;
    cell.layer.masksToBounds = true;
}


#pragma mark -
#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return categoryArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CategoriesTableViewCell *cell = (CategoriesTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"CategoriesTableViewCell"];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CategoriesTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    @try {
        cell.backgroundColor=kColorClear;
        cell.lblCategoryName.text = [NSString stringWithFormat:@"%@", [categoryArray[indexPath.row] objectForKey:@"CategoryName"]];
        cell.lblCategoryName.font=kfontSimple(18);
        cell.lblCategoryName.textColor=kColorBlack;
        
        // set the image view
        NSURL *imageURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[[categoryArray objectAtIndex:indexPath.row] objectForKey:@"photopath"]]];
        [cell.imageViewForCategory setImageWithURL:imageURL placeholderImage:nil usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        
        if (indexPath.row == intRow)
        {
            cell.imageViewForCart.image = [UIImage imageNamed:@"icon_cat_minus"];
        }
        else
        {
            cell.imageViewForCart.image = [UIImage imageNamed:@"icon_cat_plus"];
        }
        
        cell.imageViewForCart.image = [cell.imageViewForCart.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [cell.imageViewForCart setTintColor:app_delegate.appColor];
        
    }
    @catch (NSException *exception) {
        
    }
    
    // change the cell selection style
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

#pragma mark -0
#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    intRow = indexPath.row;
    
    productArray =[[NSMutableArray alloc] init];
    for (int i = 0; i < [allProductArray count]; i++) {
        if ([[[allProductArray objectAtIndex:i] objectForKey:@"CategoryId"] intValue] == [[[categoryArray objectAtIndex:indexPath.row] objectForKey:@"CategoryId"] intValue]) {
            [productArray addObject:[allProductArray objectAtIndex:i]];
        }
    }
    
    // reload the tableview and collectionview
    [tblViewCategoryList reloadData];
    [_collectionView reloadData];
}

- (IBAction)btnRoom:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)inputDate:(NSDate*)date start:(NSDate*)beginDate end:(NSDate*)endDate
{
    if ([date compare:beginDate] == NSOrderedAscending)
        return NO;
    
    if ([date compare:endDate] == NSOrderedDescending)
        return NO;
    
    return YES;
}
- (IBAction)BtncancelOfferView:(id)sender {
    
    isvolumeOfferClicked=FALSE;
    [self Removeoffer];
}

- (IBAction)btnCart:(id)sender {
    CartViewController *cartVC=[[CartViewController alloc] initWithNibName:@"CartViewController" bundle:nil];
    [self.navigationController pushViewController:cartVC animated:YES];
}
- (IBAction)btnTheme:(id)sender {
    
    ThemeViewController *themeVC=[[ThemeViewController alloc] initWithNibName:@"ThemeViewController" bundle:nil];
    [self.navigationController pushViewController:themeVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
