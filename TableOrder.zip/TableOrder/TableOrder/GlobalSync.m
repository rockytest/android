//
//  GlobalSync.m
//  Home Delivery
//
//  Created by Darshan Kunjadiya on 23/07/15.
//  Copyright (c) 2015 Darshan Kunjadiya. All rights reserved.
//

#import "GlobalSync.h"

GlobalSync *_globalSync = nil;

@implementation GlobalSync

+ (id)sharedData
{
    @synchronized(self)
    {
        if (_globalSync == nil){
            (void)[[self alloc] init]; // assignment not done here
        }
    }
    
    return _globalSync;
}

//**************************** LOGIN *************************\\

-(void)loginMethod :(NSDictionary *)aDictionary
{
    @try
    {
        
        /****** AFNetworking *******/
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setTimeoutInterval:90];
        
        NSString *strPost = [NSString stringWithFormat:@"%@%@",kAPIBASE_URL,kAPILogin];
        
        //    NSDictionary *params = @{@“first_name”:strFirstName};
        [manager GET:strPost parameters:aDictionary success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSLog(@"get response of login");
             // Dictionary to get the json response
             NSDictionary *dictResponse = responseObject;
//             NSLog(@"response dict:--> %@",dictResponse);
             
             if ([[self delegate] respondsToSelector:@selector(loginData:error:)])
             {
                 [[self delegate] loginData:dictResponse error:nil];
             }
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             NSLog(@"response failed--->> %@",error.description);
             if ([[self delegate] respondsToSelector:@selector(loginData:error:)])
             {
                 [[self delegate] loginData:nil error:error];
             }
         }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
}

#pragma mark - Register
/********************* Register ***************************/
-(void)registerMethod :(NSDictionary *)aDictionary
{
    @try
    {
        
        /****** AFNetworking *******/
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setTimeoutInterval:90];
        
        NSString *strPost = [NSString stringWithFormat:@"%@%@",kAPIBASE_URL,kAPIRegister];
        
                             //    NSDictionary *params = @{@“first_name”:strFirstName};
                             [manager GET:strPost parameters:aDictionary success:^(AFHTTPRequestOperation *operation, id responseObject)
                              {
                                  NSLog(@"get response of register");
                                  // Dictionary to get the json response
                                  NSDictionary *dictResponse = responseObject;
//                                  NSLog(@"response dict:--> %@",dictResponse);
                                  
                                  if ([[self delegate] respondsToSelector:@selector(registerData:error:)])
                                              {
                                                  [[self delegate] registerData:dictResponse error:nil];
                                              }
                                  
                              } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                                  NSLog(@"response failed--->> %@",error.description);
                                  if ([[self delegate] respondsToSelector:@selector(registerData:error:)])
                                  {
                                      [[self delegate] registerData:nil error:error];
                                  }
                              }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

#pragma mark - Get Categories

/********************* get categories ***************************/
-(void)getCategoriesMethod :(NSDictionary *)aDictionary;
{
    @try
    {
        
        /****** AFNetworking *******/
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setTimeoutInterval:90];
        
        NSString *strPost = [NSString stringWithFormat:@"%@%@",kAPIBASE_URL,kAPIGetCategories];
        
        //    NSDictionary *params = @{@“first_name”:strFirstName};
        [manager GET:strPost parameters:aDictionary success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSLog(@"get response for get categories");
             // Dictionary to get the json response
             NSDictionary *dictResponse = responseObject;
//             NSLog(@"response dict:--> %@",dictResponse);
             
             if ([[self delegate] respondsToSelector:@selector(getCategoriesData:error:)])
             {
                 [[self delegate] getCategoriesData:dictResponse error:nil];
             }
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             NSLog(@"response failed--->> %@",error.description);
             if ([[self delegate] respondsToSelector:@selector(getCategoriesData:error:)])
             {
                 [[self delegate] getCategoriesData:nil error:error];
             }
         }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

#pragma mark - Get Products

/********************* get products ***************************/
-(void)getProductsMethod :(NSDictionary *)aDictionary
{
    @try
    {
        
        /****** AFNetworking *******/
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setTimeoutInterval:90];
        
        NSString *strPost = [NSString stringWithFormat:@"%@%@",kAPIBASE_URL,kAPIGetProducts];
        
        //    NSDictionary *params = @{@“first_name”:strFirstName};
        [manager GET:strPost parameters:aDictionary success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSLog(@"get response of get products");
             // Dictionary to get the json response
             NSDictionary *dictResponse = responseObject;
//             NSLog(@"response dict:--> %@",dictResponse);
             
             if ([[self delegate] respondsToSelector:@selector(getProductsData:error:)])
             {
                 [[self delegate] getProductsData:dictResponse error:nil];
             }
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             NSLog(@"response failed--->> %@",error.description);
             if ([[self delegate] respondsToSelector:@selector(getProductsData:error:)])
             {
                 [[self delegate] getProductsData:nil error:error];
             }
         }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

/********************* get Room ***************************/
-(void)getRoomMethod :(NSDictionary *)aDictionary
{
    @try
    {
        
        /****** AFNetworking *******/
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setTimeoutInterval:90];
        
        NSString *strPost = [NSString stringWithFormat:@"%@%@",kAPIBASE_URL,kAPIGetRoom];
        
        //    NSDictionary *params = @{@“first_name”:strFirstName};
        [manager GET:strPost parameters:aDictionary success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSLog(@"get response of get products");
             // Dictionary to get the json response
             NSDictionary *dictResponse = responseObject;
             //             NSLog(@"response dict:--> %@",dictResponse);
             
             if ([[self delegate] respondsToSelector:@selector(getRoomsData:error:)])
             {
                 [[self delegate] getRoomsData:dictResponse error:nil];
             }
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             NSLog(@"response failed--->> %@",error.description);
             if ([[self delegate] respondsToSelector:@selector(getRoomsData:error:)])
             {
                 [[self delegate] getRoomsData:nil error:error];
             }
         }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
}



/********************* get BookTable ***************************/
-(void)getBookTableMethod :(NSDictionary *)aDictionary
{
    @try
    {
        
        /****** AFNetworking *******/
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setTimeoutInterval:90];
        
        NSString *strPost = [NSString stringWithFormat:@"%@%@",kAPIBASE_URL,kAPITransactionDetail];
        
        //    NSDictionary *params = @{@“first_name”:strFirstName};
        [manager GET:strPost parameters:aDictionary success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSLog(@"get response of get products");
             // Dictionary to get the json response
             NSDictionary *dictResponse = responseObject;
             //             NSLog(@"response dict:--> %@",dictResponse);
             
             if ([[self delegate] respondsToSelector:@selector(getBookTableData:error:)])
             {
                 [[self delegate] getBookTableData:dictResponse error:nil];
             }
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             NSLog(@"response failed--->> %@",error.description);
             if ([[self delegate] respondsToSelector:@selector(getBookTableData:error:)])
             {
                 [[self delegate] getBookTableData:nil error:error];
             }
         }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
}

/********************* Delete Transacation ***************************/
-(void)deleteTransacationMethod :(NSDictionary *)aDictionary
{
    @try
    {
        
        /****** AFNetworking *******/
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
//        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
//        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
//        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setTimeoutInterval:90];
        
        NSString *strPost = [NSString stringWithFormat:@"%@%@?TicketId=%@",kAPIBASE_URL,kAPIDeleteTransaction,[aDictionary objectForKey:@"TicketId"]];
        
        //    NSDictionary *params = @{@“first_name”:strFirstName};
        [manager GET:strPost parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSLog(@"get response of get products");
             // Dictionary to get the json response
             //NSDictionary *dictResponse = responseObject;
             //             NSLog(@"response dict:--> %@",dictResponse);
             
             if ([[self delegate] respondsToSelector:@selector(getDeleteTransData:error:)])
             {
                 [[self delegate] getDeleteTransData:@"" error:nil];
             }
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             NSLog(@"response failed--->> %@",error.description);
             
             if ([operation.responseData length] != 0) {
                 NSString *returnString=[[NSString alloc]initWithData:operation.responseData encoding:NSUTF8StringEncoding];
                 NSLog(@"%@",returnString);
                 
                 if ([[self delegate] respondsToSelector:@selector(getDeleteTransData:error:)])
                 {
                     [[self delegate] getDeleteTransData:returnString error:error];
                 }
             }
             
//             if ([[self delegate] respondsToSelector:@selector(getDeleteTransData:error:)])
//             {
//                 [[self delegate] getDeleteTransData:nil error:error];
//             }
         }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
}

#pragma mark - Forgot Password

/********************* forgot password ***************************/
-(void)forgotPasswordMethod :(NSDictionary *)aDictionary
{
//    @try
//    {
//        NSString *post =[NSString stringWithFormat:@"user_email=%@&api_key=%@",[aDictionary objectForKey:@"user_email"],kAPIKey];
//        NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
//        NSString *postLength = [NSString stringWithFormat:@"%lu",(unsigned long)[postData length]];
//        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//        [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kAPIBASE_URL,kAPIForgotPassword]]];
//        [request setHTTPMethod:@"POST"];
//        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
//        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
//        [request setHTTPBody:postData];
//        NSError *error;
//        NSURLResponse *response;
//        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
//        NSString *str=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
//        NSDictionary *forgotPasswordDict=[str JSONValue];
//        
//        if ([[self delegate] respondsToSelector:@selector(forgotPasswordData:error:)])
//        {
//            [[self delegate] forgotPasswordData:forgotPasswordDict error:error];
//        }
//        
//    }
//    @catch (NSException *exception) {
//        
//    }
//    @finally {
//        
//    }
}

@end
