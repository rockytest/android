//
//  MainRoomViewController.m
//  TableOrder
//
//  Created by Macmini on 11/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "MainRoomViewController.h"
#import "CategoriesViewController.h"

@interface MainRoomViewController ()

@end

@implementation MainRoomViewController

- (void)viewDidLoad {
    
    // allocate and initialize progress bar
    HUD = [[MBProgressHUD alloc] initWithFrame:CGRectMake(kScreenHeight/2 - 15, kScreenWidth/2 - 15, 30, 30)];
    [self.view addSubview:HUD];
    
    [HUD show:YES];
    _globalSync.delegate=self;
    [_globalSync performSelector:@selector(getProductsMethod:) withObject:nil afterDelay:0.1];
    
    _globalSync.delegate = self;
    [_globalSync performSelector:@selector(getCategoriesMethod:) withObject:@{@"CategoryId":@"0"} afterDelay:0.1];
    
    currentSelection=0;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
#pragma mark-
#pragma mark- Get Category API Response
-(void)getCategoriesData :(NSDictionary *)aGetCategoriesDict error:(NSError *)aError
{
    NSLog(@"category list:-->> %@",aGetCategoriesDict);
    
    @try {
        
        NSMutableArray *allCategoryArray=(NSMutableArray *)aGetCategoriesDict;
        NSData *myEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:allCategoryArray];
        [UserDefaults setObject:myEncodedObject forKey:[NSString stringWithFormat:@"CategoryListArray"]];
        [UserDefaults synchronize];
    }
    @catch (NSException *exception) {
        
    }
}

#pragma mark-
#pragma mark- Get Product API Response
-(void)getProductsData :(NSDictionary *)aGetProductsDict error:(NSError *)aError
{
    NSLog(@"%@",aGetProductsDict);
    
    @try {
        
        NSMutableArray *allProductArray=(NSMutableArray *)aGetProductsDict;
        NSData *myEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:allProductArray];
        [UserDefaults setObject:myEncodedObject forKey:[NSString stringWithFormat:@"ProductListArray"]];
        [UserDefaults synchronize];
    }
    @catch (NSException *exception) {
        
    }
    
    // stop activity indicator
    [HUD hide:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [self.indicatorRooms startAnimating];
    [self performSelector:@selector(callRoomDataAPI) withObject:nil afterDelay:0.1];
    [super viewWillAppear:YES];
}

-(void)callRoomDataAPI
{
    [self.indicatorRooms startAnimating];
    _globalSync.delegate=self;
    [_globalSync performSelector:@selector(getRoomMethod:) withObject:@{@"RoomId" : @"0"} afterDelay:0.1];
}
-(void)getRoomsData :(NSDictionary *)aGetRoomsDict error:(NSError *)aError
{
    [[_scrlTableRoom subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    allRoomsArray=(NSMutableArray *)aGetRoomsDict;
    roomsArray=[[allRoomsArray objectAtIndex:currentSelection] objectForKey:@"RoomTable"];
    
    [[_scrlRoom subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    int x=0;
    for (int i=0; i < [allRoomsArray count]; i++)
    {
        UIButton *buttonRoom=[UIButton buttonWithType:UIButtonTypeCustom];
        CGSize fontSize;
        fontSize = [[[allRoomsArray objectAtIndex:i] objectForKey:@"Room"] sizeWithAttributes:
                    @{NSFontAttributeName: kfontSemibold(12)}];
        
        buttonRoom.layer.borderColor = [kColorClear CGColor];
        buttonRoom.layer.borderWidth = 0;
        buttonRoom.layer.cornerRadius = 4;
        buttonRoom.layer.masksToBounds = true;
        
        buttonRoom.tag=i;
        CGRect buttonFrame;
        if (iPad) {
            buttonFrame = CGRectMake(x+(5), 10, fontSize.width + 60.0, 55);
            buttonRoom.titleLabel.font=kfontSemibold(20);
            x+=fontSize.width + 75.0;
        } else {
            buttonFrame = CGRectMake(x+(5), 5, fontSize.width + 45.0, 40);
            buttonRoom.titleLabel.font=kfontSemibold(15);
            x+=fontSize.width + 60.0;
        }
        
        buttonRoom.frame=buttonFrame;
        [buttonRoom setTitle:[[allRoomsArray objectAtIndex:i] objectForKey:@"Room"] forState:UIControlStateNormal];
        [buttonRoom addTarget:self action:@selector(btnMainRoomClick:) forControlEvents:UIControlEventTouchUpInside];
        if (i==currentSelection) {
            buttonRoom.backgroundColor=RGBA(75, 128, 41, 1);
        } else {
            buttonRoom.backgroundColor=kColorApp;
        }
        
        [_scrlRoom addSubview:buttonRoom];
        
    }
    _scrlRoom.contentSize=CGSizeMake(x+35.0 ,40);
    
    [self performSelector:@selector(displayRoom) withObject:nil afterDelay:0.1];
    
    [self.indicatorRooms stopAnimating];
}

-(IBAction)btnMainRoomClick:(id)sender
{
    UIButton *btn=(UIButton *)sender;
    
    for(UIView * subView in _scrlRoom.subviews )
    {
        if([subView isKindOfClass:[UIButton class]]) // Check is SubView Class Is UIButton class?
        {
            UIButton *button = (UIButton*)subView;
            button.backgroundColor=kColorApp;
        }
    }
    
    btn.backgroundColor=RGBA(75, 128, 41, 1);
    roomsArray=[[NSMutableArray alloc] init];
    roomsArray=[[allRoomsArray objectAtIndex:[sender tag]] objectForKey:@"RoomTable"];
    
    currentSelection=(int)[sender tag];
    
    [self performSelector:@selector(displayRoom) withObject:nil afterDelay:0.1];
}
-(void)displayRoom
{
    [[_scrlTableRoom subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    for (int i = 0; i < [roomsArray count]; i++) {
        
        UIButton *btnRoom = [UIButton buttonWithType:UIButtonTypeCustom];
        float xpo=[[[roomsArray objectAtIndex:i]objectForKey:@"Xpos"] floatValue];
        float ypos=[[[roomsArray objectAtIndex:i]objectForKey:@"Ypos"] floatValue];
        btnRoom.frame=CGRectMake(xpo,ypos , 70, 70);
        btnRoom.tag=i;
        btnRoom.titleLabel.font=kfontBold(14);
        [btnRoom sd_setBackgroundImageWithURL:[NSURL URLWithString:[[roomsArray objectAtIndex:i] objectForKey:@"TableImage"]] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
        [btnRoom setTitle:[NSString stringWithFormat:@"%@",[[roomsArray objectAtIndex:i] objectForKey:@"TableNo"]] forState:UIControlStateNormal];
        
        if ([[[roomsArray objectAtIndex:i] objectForKey:@"TicketId"] intValue] != 0) {
            UILongPressGestureRecognizer *gr = [[UILongPressGestureRecognizer alloc] init];
            [gr addTarget:self action:@selector(longPress:)];
            [btnRoom addGestureRecognizer:gr];
            [btnRoom addTarget:self action:@selector(btnRoomDetailClick:) forControlEvents:UIControlEventTouchUpInside];
        } else {
            [btnRoom addTarget:self action:@selector(btnRoomClick:) forControlEvents:UIControlEventTouchUpInside];
        }
        [_scrlTableRoom addSubview:btnRoom];
    }
    
    NSInteger maxX = [[roomsArray valueForKeyPath:@"@max.Xpos"] integerValue];
    NSInteger maxY = [[roomsArray valueForKeyPath:@"@max.Ypos"] integerValue];
    
    _scrlTableRoom.contentSize=CGSizeMake(maxX+60, maxY+60);
}

- (void)longPress:(UILongPressGestureRecognizer*)gesture {
    
    if ( gesture.state == UIGestureRecognizerStateBegan) {
        NSLog(@"Long Press");
        
        deleteTableTag=gesture.view.tag;
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Delete Table Order" message:@"Are you sure want to delete this table order?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"No", nil];
        alert.tag=1;
        [alert show];
        
        NSLog(@"user long pressed");
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==1)
    {
        if(buttonIndex==0)
        {
            [self.indicatorRooms startAnimating];
            [_globalSync performSelector:@selector(deleteTransacationMethod:) withObject:@{@"TicketId":[[roomsArray objectAtIndex:deleteTableTag] objectForKey:@"TicketId"]} afterDelay:0.1];
        }
    }
}
-(void)getDeleteTransData :(NSString *)aGetTransactionString error:(NSError *)aError
{
    NSLog(@"%@",aGetTransactionString);
    if ([aGetTransactionString isEqualToString:@"true"]) {
        [self.indicatorRooms startAnimating];
        
        [app_delegate.sk deleteWhere:[NSString stringWithFormat:@"roomid=%@ and Tableno=%@",[[roomsArray objectAtIndex:deleteTableTag] objectForKey:@"RoomId"],[[roomsArray objectAtIndex:deleteTableTag] objectForKey:@"TableNo"]] forTable:@"AddProduct"];
        
        [self performSelector:@selector(callRoomDataAPI) withObject:nil afterDelay:0.1];
    } else {
        [self.indicatorRooms stopAnimating];
    }
}

-(IBAction)btnRoomDetailClick:(id)sender
{
    selectedTableTag=[sender tag];
    [self.indicatorRooms startAnimating];
    [_globalSync performSelector:@selector(getBookTableMethod:) withObject:@{@"TicketId" : [[roomsArray objectAtIndex:[sender tag]] objectForKey:@"TicketId"]} afterDelay:0.1];
    self.view.userInteractionEnabled=FALSE;
}
-(void)getBookTableData :(NSDictionary *)aGetBookTableDict error:(NSError *)aError
{
    self.view.userInteractionEnabled=TRUE;
    [app_delegate.sk deleteWhere:[NSString stringWithFormat:@"roomid=%@ and Tableno=%@",[[roomsArray objectAtIndex:selectedTableTag] objectForKey:@"RoomId"],[[roomsArray objectAtIndex:selectedTableTag] objectForKey:@"TableNo"]] forTable:@"AddProduct"];
    
    NSLog(@"%@",aGetBookTableDict);
    
    
    if (![[aGetBookTableDict objectForKey:@"transactiondetails"] isKindOfClass:[NSNull class]]) {
        
        NSMutableArray *tableOrderArray=[aGetBookTableDict objectForKey:@"transactiondetails"];
        
        for (int i = 0; i < [tableOrderArray count]; i++) {
            
            NSMutableDictionary *insertDatabaseDict=[[NSMutableDictionary alloc] init];
            [insertDatabaseDict setObject:@"" forKey:@"CategoryId"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"ItemId"])] forKey:@"ItemId"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"Products"])] forKey:@"ItemName"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"SalesFormatId"])] forKey:@"ItemSaleFormatId"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"Price"])] forKey:@"Price"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"Unit"])] forKey:@"qty"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"Discount"])] forKey:@"discount"];
            
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"IsExtra"])] forKey:@"isExtra"];
            
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([aGetBookTableDict objectForKey:@"TableNo"])] forKey:@"Tableno"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([aGetBookTableDict objectForKey:@"RoomId"])] forKey:@"roomid"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([aGetBookTableDict objectForKey:@"EmployeeId"])] forKey:@"employeeid"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"free_qty"])] forKey:@"freeqty"];
            
            if ([[[tableOrderArray objectAtIndex:i] objectForKey:@"PromotionId"] intValue] == 0) {
                [insertDatabaseDict setObject:@"0" forKey:@"isOffer"];
            } else {
                [insertDatabaseDict setObject:@"1" forKey:@"isOffer"];
            }
            
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"TicketId"])] forKey:@"Ticketid"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"SubTotal"])] forKey:@"subtotal"];
            [insertDatabaseDict setObject:@"" forKey:@"commentname"];
            [insertDatabaseDict setObject:@"0" forKey:@"iscommentAdd"];
            [insertDatabaseDict setObject:@"" forKey:@"Extraname"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"PromotionId"])] forKey:@"Promotionid"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"ExtraRowId"])] forKey:@"ExtraRowId"];
            
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"RowId"])] forKey:@"RowId"];
            
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"ExtraItemId"])] forKey:@"Extraitemid"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"Sequence"])] forKey:@"sequence"];
            [insertDatabaseDict setObject:[NSString stringWithFormat:@"%@",NULL_TO_NIL([[tableOrderArray objectAtIndex:i] objectForKey:@"IsExtra"])] forKey:@"isextraAdd"];
            [insertDatabaseDict setObject:@"" forKey:@"finalcomment"];
            [insertDatabaseDict setObject:@"1" forKey:@"IsPrint"];
            [app_delegate.sk insertDictionary:insertDatabaseDict forTable:@"AddProduct"];
        }
    }
    
    
    [UserDefaults setObject:[[roomsArray objectAtIndex:selectedTableTag] objectForKey:@"TableId"] forKey:@"TableId"];
    [UserDefaults setObject:[[roomsArray objectAtIndex:selectedTableTag] objectForKey:@"RoomId"] forKey:@"RoomId"];
    [UserDefaults setObject:[[roomsArray objectAtIndex:selectedTableTag] objectForKey:@"TicketId"] forKey:@"TicketId"];
    [UserDefaults setObject:[[roomsArray objectAtIndex:selectedTableTag] objectForKey:@"TableNo"] forKey:@"TableNo"];
    [UserDefaults synchronize];
    
    
    CategoriesViewController *catVC=[[CategoriesViewController alloc] initWithNibName:@"CategoriesViewController" bundle:nil];
    [self.navigationController pushViewController:catVC animated:YES];
    
    [self.indicatorRooms stopAnimating];
}

-(IBAction)btnRoomClick:(id)sender
{
    [UserDefaults setObject:[[roomsArray objectAtIndex:[sender tag]] objectForKey:@"TableId"] forKey:@"TableId"];
    [UserDefaults setObject:[[roomsArray objectAtIndex:[sender tag]] objectForKey:@"RoomId"] forKey:@"RoomId"];
    [UserDefaults setObject:[[roomsArray objectAtIndex:[sender tag]] objectForKey:@"TicketId"] forKey:@"TicketId"];
    [UserDefaults setObject:[[roomsArray objectAtIndex:[sender tag]] objectForKey:@"TableNo"] forKey:@"TableNo"];
    [UserDefaults synchronize];
    
    CategoriesViewController *catVC=[[CategoriesViewController alloc] initWithNibName:@"CategoriesViewController" bundle:nil];
    [self.navigationController pushViewController:catVC animated:YES];
    
}
- (IBAction)btnRefresh:(id)sender {
    [self performSelector:@selector(callRoomDataAPI) withObject:nil afterDelay:0.1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
