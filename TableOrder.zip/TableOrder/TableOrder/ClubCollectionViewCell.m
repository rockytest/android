//
//  ClubCollectionViewCell.m
//  GameDayXtra
//
//  Created by macmini on 13/08/15.
//
//

#import "ClubCollectionViewCell.h"

@implementation ClubCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        // Initialization code
        NSArray *arrayOfViews;
        if (iPad) {
           arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"ClubCollectionViewCell_ipad" owner:self options:nil];
        } else {
            arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"ClubCollectionViewCell" owner:self options:nil];
        }
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
    }
    
    return self;
    
}
@end
