//
//  CartItemCell.h
//  TableOrder
//
//  Created by Macmini on 15/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CartItemCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblItemName;
@property (weak, nonatomic) IBOutlet UILabel *lblQTY;
@property (weak, nonatomic) IBOutlet UIButton *refBtnRemoveItem;
@property (weak, nonatomic) IBOutlet UILabel *lblPrice;

@end
