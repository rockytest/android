//
//  CategoriesViewController.h
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoriesViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,GlobalApiDelegate>
{
    NSMutableArray *allProductArray;
    NSMutableArray *productArray;
    NSMutableArray *categoryArray;
    
    // array to store the category list name
    NSMutableArray *listArray;
    
    // array to store the category image name
    NSMutableArray *imgArray;
    
    // array to store the category id
    NSMutableArray *categoryIdArray;
    
    // table view to display the categories
    IBOutlet UITableView *tblViewCategoryList;
    
    NSInteger intRow;
    
    // Progress HUD
    MBProgressHUD *HUD;
    
    
    // Offer Data
    
    NSMutableArray *offerArray;
    NSMutableArray *NewofferArray;
    
    BOOL isOfferClicked;
    int OfferTag;
    BOOL isvolumeOfferClicked;
    
    
    NSDateFormatter *dateFormat;
    NSDateFormatter *TimeFormat;
    
    //OfferView Potrait ipad
    IBOutlet UIView *MainOfferView_potraiti;
    IBOutlet UIView *innerOfferView_potraiti;
    IBOutlet UIScrollView *OfferScroll_potraiti;
    IBOutlet UIImageView *imgSpecialOffer_potraiti;
    
    
    //Volume OfferView Potrait
    IBOutlet UIView *MainVolumeOfferView_potrait;
    IBOutlet UIView *innerVolumeOfferView_potrait;
    IBOutlet UIScrollView *VolumeOfferScroll_potrait;

}
@property (weak, nonatomic) IBOutlet UILabel *lblHeader;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
- (IBAction)btnRoom:(id)sender;
- (IBAction)BtncancelOfferView:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblCartItemName;
@property (weak, nonatomic) IBOutlet UILabel *lblCartItemQTY;
@property (weak, nonatomic) IBOutlet UILabel *lblTotalPrice;
- (IBAction)btnCancel:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *refBtnCancel;
- (IBAction)btnCart:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblDoller;
@property (weak, nonatomic) IBOutlet UILabel *lblCategoryHeader;
- (IBAction)btnTheme:(id)sender;

@end
