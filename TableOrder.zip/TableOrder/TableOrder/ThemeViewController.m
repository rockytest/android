//
//  ThemeViewController.m
//  TableOrder
//
//  Created by Macmini on 16/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "ThemeViewController.h"

@interface ThemeViewController ()

@end

@implementation ThemeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (IBAction)btnChangeColor:(id)sender {
    
    if ([sender tag] == 0)
    {
        app_delegate.appColor=RGBA(255, 0, 255, 1.0);
    }
    else if ([sender tag] == 1)
    {
        app_delegate.appColor=RGBA(0, 255, 0, 1.0);
    }
    else if ([sender tag] == 2)
    {
        app_delegate.appColor=RGBA(0, 255, 255, 1.0);
    }
    else if ([sender tag] == 3)
    {
        app_delegate.appColor=RGBA(127, 0, 127, 1.0);
    }
    else if ([sender tag] == 4)
    {
        app_delegate.appColor=RGBA(255, 0, 0, 1.0);
    }
    // save the color in userdefaults
    NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:app_delegate.appColor];
    [UserDefaults setObject:colorData forKey:@"app_color"];
    [UserDefaults synchronize];

    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
