//
//  CartViewController.m
//  TableOrder
//
//  Created by Macmini on 15/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "CartItemCell.h"
#import "CartViewController.h"
#import "MainRoomViewController.h"
#import "MainRoomViewController.h"

@interface CartViewController ()

@end

@implementation CartViewController

- (void)viewDidLoad {
    
    NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
    
    app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
    
    NSLog(@"%@",app_delegate.CartItemData);
    
    [_tblCart reloadData];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    _viewFooterBG.backgroundColor=app_delegate.appColor;
    [_refSaveOrder setBackgroundColor:app_delegate.appColor];
}

#pragma mark -
#pragma mark - UITableViewDataSource
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float totalAmout=0;
    for (int i = 0; i < [app_delegate.CartItemData count]; i++) {
        if (totalAmout == 0) {
            totalAmout =[[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"subtotal"] floatValue];
        } else {
            totalAmout =  totalAmout +[[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"subtotal"] floatValue];
        }
    }
    _lblTotalAmount.text=[NSString stringWithFormat:@"$ %.1f",totalAmout];
    _viewFooter.frame=CGRectMake(0, 100, kScreenWidth, _viewFooter.frame.size.height);
    return _viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 127;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return app_delegate.CartItemData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CartItemCell *cell = (CartItemCell *)[tableView dequeueReusableCellWithIdentifier:@"CartItemCell"];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CartItemCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    @try {
        cell.backgroundColor=kColorClear;
        if ([[[app_delegate.CartItemData objectAtIndex:indexPath.row] objectForKey:@"isOffer"] isEqualToString:@"1"]) {
            cell.lblItemName.text = [NSString stringWithFormat:@"%@(Offer)", [app_delegate.CartItemData[indexPath.row] objectForKey:@"ItemName"]];
        } else {
            cell.lblItemName.text = [NSString stringWithFormat:@"%@", [app_delegate.CartItemData[indexPath.row] objectForKey:@"ItemName"]];
        }
        
        cell.lblQTY.text=[NSString stringWithFormat:@"%@ X $ %@.00",[app_delegate.CartItemData[indexPath.row] objectForKey:@"qty"],[[app_delegate.CartItemData objectAtIndex:indexPath.row] objectForKey:@"Price"]];
        
        
        NSLog(@"Print %@",[[app_delegate.CartItemData objectAtIndex:indexPath.row] objectForKey:@"IsPrint"]);
        
        if ([[[app_delegate.CartItemData objectAtIndex:indexPath.row] objectForKey:@"IsPrint"] intValue] == 1) {
            cell.refBtnRemoveItem.hidden=TRUE;
            cell.lblPrice.hidden=FALSE;
            
            cell.lblPrice.text=[NSString stringWithFormat:@"$ %@",[[app_delegate.CartItemData objectAtIndex:indexPath.row] objectForKey:@"subtotal"]];
            
        } else {
            
            cell.refBtnRemoveItem.hidden=FALSE;
            cell.lblPrice.hidden=TRUE;
            
            cell.refBtnRemoveItem.tag=indexPath.row;
            [cell.refBtnRemoveItem addTarget:self
                                      action:@selector(aRemoveCartItem:)
                            forControlEvents:UIControlEventTouchUpInside];
            
            [cell.refBtnRemoveItem setTitle:[NSString stringWithFormat:@"$ %@",[[app_delegate.CartItemData objectAtIndex:indexPath.row] objectForKey:@"subtotal"]] forState:UIControlStateNormal];
        }
    }
    @catch (NSException *exception) {
        
    }
    
    // change the cell selection style
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[[app_delegate.CartItemData objectAtIndex:indexPath.row] objectForKey:@"IsPrint"] intValue] != 1)
    {
        isAddtoCartClicked=TRUE;
        AddtoCartTag=(int)indexPath.row;
        
        MainAddtoCartView_potrait_ipad.frame=CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height);
        [self.view addSubview:MainAddtoCartView_potrait_ipad];
        [self setCartDetailItemPotrait_ipad];
    }
}

-(void)setCartDetailItemPotrait_ipad
{
    innerAddtocartView_potrait_ipad.frame=CGRectMake(230,180,320,305);
    innerAddtocartView_potrait_ipad.center=self.view.center;
    
    Cartitem_name_potrait_ipad.text=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag]objectForKey:@"ItemName"]];
    
    innerAddtocartView_potrait_ipad.layer.borderWidth=1.0f;
    innerAddtocartView_potrait_ipad.layer.cornerRadius=3.0f;
    innerAddtocartView_potrait_ipad.layer.borderColor=[[UIColor whiteColor] CGColor];
    
    NSString *offerQty=[NSString stringWithFormat:@"%.0f",[[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"qty"]] floatValue]+[[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"freeqty"]] floatValue]];
    
    
    if ([[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"freeqty"]] isEqualToString:@"0"])
    {
        CartDetailQtyText_potrait_ipad.text=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag]objectForKey:@"qty"]];
    }
    else
    {
        CartDetailQtyText_potrait_ipad.text=[NSString stringWithFormat:@"%@",offerQty];
    }
    
    CartDetailPriceText_potrait_ipad.text=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag]objectForKey:@"Price"]];
    CartDetailDiscountText_potrait_ipad.text=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag]objectForKey:@"discount"]];
    
    if ([[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"isOffer"]] isEqualToString:@"1"])
    {
        CartDetailQtyText_potrait_ipad.enabled=NO;
        CartDetailPriceText_potrait_ipad.enabled=NO;
        CartDetailDiscountText_potrait_ipad.enabled=NO;
    }
    else
    {
        CartDetailQtyText_potrait_ipad.enabled=YES;
        CartDetailPriceText_potrait_ipad.enabled=YES;
        CartDetailDiscountText_potrait_ipad.enabled=YES;
        [CartDetailQtyText_potrait_ipad becomeFirstResponder];
    }
    
    NSString *Total=[NSString stringWithFormat:@"%f",[CartDetailQtyText_potrait_ipad.text floatValue]*[CartDetailPriceText_potrait_ipad.text floatValue]];
    NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[CartDetailDiscountText_potrait_ipad.text floatValue]];
    NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
    NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f £",[Total floatValue]-[finalTotal floatValue]];
    CartDetailTotalText_potrait_ipad.text=fullFinalTotal;
}

-(IBAction)aRemoveCartItem:(id)sender
{
    AddtoCartTag=(int)[sender tag];
    
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Confirmation" message:@"Are you sure want to remove this item from cart ?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"No", nil];
    alert.tag=1;
    [alert show];
}

-(IBAction)saveCartItemClick:(id)sender
{
    NSMutableDictionary *UpdataDictForFav=[[NSMutableDictionary alloc] init];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"CategoryId"] forKey:@"CategoryId"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"ItemId"] forKey:@"ItemId"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"ItemName"] forKey:@"ItemName"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"ItemSaleFormatId"] forKey:@"ItemSaleFormatId"];
    [UpdataDictForFav setObject:CartDetailPriceText_potrait_ipad.text forKey:@"Price"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"Tableno"] forKey:@"Tableno"];
    [UpdataDictForFav setObject:CartDetailDiscountText_potrait_ipad.text forKey:@"discount"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"employeeid"] forKey:@"employeeid"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"id"] forKey:@"id"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"isExtra"] forKey:@"isExtra"];
    
    NSString *qtys;
    if ([[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"freeqty"]] isEqualToString:@"0"])
    {
        [UpdataDictForFav setObject:CartDetailQtyText_potrait_ipad.text forKey:@"qty"];
        qtys=CartDetailQtyText_potrait_ipad.text;
    }
    else
    {
        NSString *Total=[NSString stringWithFormat:@"%.0f",[CartDetailQtyText_potrait_ipad.text floatValue]-[[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"freeqty"]] floatValue]];
        [UpdataDictForFav setObject:[NSString stringWithFormat:@"%@",Total] forKey:@"qty"];
        qtys=[NSString stringWithFormat:@"%@",Total];
    }
    
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"roomid"] forKey:@"roomid"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"freeqty"] forKey:@"freeqty"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"isOffer"] forKey:@"isOffer"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"Ticketid"] forKey:@"Ticketid"];
    
    
    NSString*strqty;
    NSString*strprice;
    NSString*strDiscount;
    
    strqty=[NSString stringWithFormat:@"%@",qtys];
    strprice=[NSString stringWithFormat:@"%@",CartDetailPriceText_potrait_ipad.text];
    strDiscount=[NSString stringWithFormat:@"%@",CartDetailDiscountText_potrait_ipad.text];
    NSString *Total=[NSString stringWithFormat:@"%f",[strqty floatValue]*[strprice floatValue]];
    NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[strDiscount floatValue]];
    NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
    NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f",[Total floatValue]-[finalTotal floatValue]];
    
    [UpdataDictForFav setObject:fullFinalTotal forKey:@"subtotal"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"commentname"] forKey:@"commentname"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"Extraname"] forKey:@"Extraname"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"Promotionid"] forKey:@"Promotionid"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"ExtraRowId"] forKey:@"ExtraRowId"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"RowId"] forKey:@"RowId"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"Extraitemid"] forKey:@"Extraitemid"];
    [UpdataDictForFav setObject:@"0" forKey:@"sequence"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"isextraAdd"] forKey:@"isextraAdd"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"iscommentAdd"] forKey:@"iscommentAdd"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"finalcomment"] forKey:@"finalcomment"];
    [UpdataDictForFav setObject:[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"IsPrint"] forKey:@"IsPrint"];
    
    
    NSString *wherestr=[NSString stringWithFormat:@"roomid=%@ and Tableno=%@ and id=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"],[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"id"]];
    
    [app_delegate.sk updateDictionary:UpdataDictForFav forTable:@"AddProduct" where:wherestr];
    
    NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
    
    app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
    
    [self Qty_price];
    [_tblCart reloadData];
    
    [MainAddtoCartView_potrait_ipad removeFromSuperview];
    
    isAddtoCartClicked=FALSE;
}
-(void)Qty_price
{
    sum=0.0;
    qty=0;
    
    NSString*strqty;
    NSString *strFreeqty;
    
    NSString*strprice;
    NSString*strDiscount;
    
    for (int i=0; i<[app_delegate.CartItemData count]; i++)
    {
        strqty=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:i]objectForKey:@"qty"]];
        strFreeqty=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:i]objectForKey:@"freeqty"]];
        strprice=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:i]objectForKey:@"Price"]];
        strDiscount=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:i]objectForKey:@"discount"]];
        
        if ([[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"freeqty"]] isEqualToString:@"0"])
        {
            qty=qty+(int)[strqty floatValue];
        }
        else
        {
            qty=qty+(int)[strqty floatValue]+(int)[strFreeqty floatValue];
        }
        NSString *Total=[NSString stringWithFormat:@"%f",[strqty floatValue]*[strprice floatValue]];
        NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[strDiscount floatValue]];
        NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
        NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f",[Total floatValue]-[finalTotal floatValue]];
        sum=sum+[fullFinalTotal floatValue];
    }
    _lblTotalAmount.text=[NSString stringWithFormat:@"%.2f £",sum];
    //lblqty.text=[NSString stringWithFormat:@"%d",qty];
}

-(IBAction)CancelCartItemClick:(id)sender
{
    isAddtoCartClicked=FALSE;
    [MainAddtoCartView_potrait_ipad removeFromSuperview];
}

#pragma mark - TextField Delegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (isAddtoCartClicked==TRUE)
    {
        NSString *candidateString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        NSCharacterSet *charSet = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"];
        NSCharacterSet *SymobolSet = [NSCharacterSet punctuationCharacterSet];
        NSCharacterSet *SymobolSet1 = [NSCharacterSet symbolCharacterSet];
        
        for (int i = 0; i < [candidateString length]; i++) {
            unichar c = [candidateString characterAtIndex:i];
            if ([charSet characterIsMember:c]) {
                return NO;
            }
            if ([SymobolSet characterIsMember:c]) {
                return NO;
            }
            if ([SymobolSet1 characterIsMember:c]) {
                return NO;
            }
        }
        
        if (textField==CartDetailQtyText_potrait_ipad)
        {
            NSString *candidateString = [textField.text stringByReplacingCharactersInRange:range withString:string];
            NSString *Total=[NSString stringWithFormat:@"%f",[candidateString floatValue]*[CartDetailPriceText_potrait_ipad.text floatValue]];
            NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[CartDetailDiscountText_potrait_ipad.text floatValue]];
            NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
            NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f £",[Total floatValue]-[finalTotal floatValue]];
            CartDetailTotalText_potrait_ipad.text=fullFinalTotal;
        }
        else if (textField==CartDetailPriceText_potrait_ipad)
        {
            NSString *candidateString = [textField.text stringByReplacingCharactersInRange:range withString:string];
            NSString *Total=[NSString stringWithFormat:@"%f",[CartDetailQtyText_potrait_ipad.text floatValue]*[candidateString floatValue]];
            NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[CartDetailDiscountText_potrait_ipad.text floatValue]];
            NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
            NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f £",[Total floatValue]-[finalTotal floatValue]];
            CartDetailTotalText_potrait_ipad.text=fullFinalTotal;
        }
        else if (textField==CartDetailDiscountText_potrait_ipad)
        {
            NSString *candidateString = [textField.text stringByReplacingCharactersInRange:range withString:string];
            if ([candidateString integerValue]>=100)
            {
                return NO;
            }
            else
            {
                NSString *Total=[NSString stringWithFormat:@"%f",[CartDetailQtyText_potrait_ipad.text floatValue]*[CartDetailPriceText_potrait_ipad.text floatValue]];
                NSString *discountTotal=[NSString stringWithFormat:@"%f",[Total floatValue]*[candidateString floatValue]];
                NSString *finalTotal=[NSString stringWithFormat:@"%f",[discountTotal floatValue]/100.0f];
                NSString *fullFinalTotal=[NSString stringWithFormat:@"%.2f £",[Total floatValue]-[finalTotal floatValue]];
                CartDetailTotalText_potrait_ipad.text=fullFinalTotal;
                return YES;
            }
        }
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)btnClose:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnRoom:(id)sender {
    MainRoomViewController *mainRoomViewController=[[MainRoomViewController alloc] initWithNibName:@"MainRoomViewController" bundle:nil];
    [self.navigationController pushViewController:mainRoomViewController animated:YES];
}

- (IBAction)btnSaveOrder:(id)sender {
    
    if ([app_delegate.CartItemData count]==0)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Message" message:@"Please Add Item In Cart" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        
        [alert show];
    }
    else
    {
        if ([[NSString stringWithFormat:@"%@",[UserDefaults objectForKey:@"TicketId"]] isEqualToString:@"0"])
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Confirmation" message:@"Are you want to save order?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"No", nil];
            alert.tag=2;
            [alert show];
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Confirmation" message:@"Are you want to update order?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"No", nil];
            alert.tag=2;
            [alert show];
        }
    }
}

#pragma mark - AlertTextview Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==1)
    {
        if(buttonIndex==0)
        {
            [app_delegate.sk deleteWhere:[NSString stringWithFormat:@"id=%@",[[app_delegate.CartItemData objectAtIndex:AddtoCartTag] objectForKey:@"id"]] forTable:@"AddProduct"];
            
            NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
            
            app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
            
            if([app_delegate.CartItemData count] == 0) {
                [self.navigationController popViewControllerAnimated:YES];
            }
            [_tblCart reloadData];
            
        }
    }
    else if (alertView.tag==2)
    {
        if(buttonIndex==0)
        {
            [self.indicatorCart startAnimating];
            [self performSelector:@selector(checkOutCartProductMethod) withObject:nil afterDelay:0.1];
        }
    }
}

-(void)checkOutCartProductMethod
{
    
    NSMutableArray *transactiondetails=[[NSMutableArray alloc]init];
    NSMutableDictionary *newvalue;
    
    for (int i=0; i<[app_delegate.CartItemData count];i++)
    {
        
        newvalue=[[NSMutableDictionary alloc]init];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"Promotionid"] forKey:@"PromotionId"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"ItemId"] forKey:@"ItemId"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"ItemSaleFormatId"] forKey:@"SalesFormatId"];
        if ([[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"isextraAdd"]] isEqualToString:@"1"])
        {
            [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"Extraname"] forKey:@"Products"];
        }
        else
        {
            [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"ItemName"] forKey:@"Products"];
        }
        
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"ExtraRowId"] forKey:@"ExtraRowId"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"RowId"] forKey:@"RowId"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"IsPrint"] forKey:@"IsPrint"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"Ticketid"] forKey:@"TicketId"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"qty"] forKey:@"Unit"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"subtotal"] forKey:@"SubTotal"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"Extraitemid"] forKey:@"ExtraItemId"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"Price"] forKey:@"Price"];
        
        NSString *finalcomment=[NSString stringWithFormat:@"%@",[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"finalcomment"]];
        finalcomment = [finalcomment substringToIndex:finalcomment.length-(finalcomment.length>0)];
        
        NSArray *finalCommentArray = [finalcomment componentsSeparatedByString: @"`"];
        
        NSMutableArray *setFinalcommentArray=[[NSMutableArray alloc]init];
        
        if (finalcomment.length!=0)
        {
            for(int i=0;i<[finalCommentArray count];i++)
            {
                [setFinalcommentArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:[finalCommentArray objectAtIndex:i],@"Comment", nil]];
            }
        }
        
        [newvalue setObject:setFinalcommentArray forKey:@"ItemComment"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"isextraAdd"] forKey:@"IsExtra"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"discount"] forKey:@"Discount"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"freeqty"] forKey:@"free_qty"];
        [newvalue setObject:@"0" forKey:@"Sequence"];
        [newvalue setObject:[[app_delegate.CartItemData objectAtIndex:i] objectForKey:@"employeeid"] forKey:@"EmployeeId"];
        [transactiondetails addObject:newvalue];
    }
    
    NSString *jsonString = [[[NSDictionary alloc]initWithObjectsAndKeys:transactiondetails,@"transactiondetails", nil] JSONRepresentation];
    NSLog(@"Json Data:%@",jsonString);
    
    NSString *totalStr=[NSString stringWithFormat:@"%@",_lblTotalAmount.text];
    totalStr = [totalStr  stringByReplacingOccurrencesOfString:@"$ " withString:@""];
    
    NSString *flag;
    if ([[NSString stringWithFormat:@"%@",[UserDefaults objectForKey:@"TicketId"]] isEqualToString:@"0"]) {
        flag=@"I";
    } else {
        flag=@"E";
    }
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    NSString *urlString=[NSString stringWithFormat:@"http://restaurantposservice.rlogical.com/REST_MOBILE_SVC.svc/SaveTransaction?TicketId=%@&PriceListId=%@&EmployeeId=%@&Total=%@&RoomId=%@&TableId=%@&TableNo=%@&transtype=Collection&flag=%@",[UserDefaults objectForKey:@"TicketId"],[UserDefaults objectForKey:@"PriceListId"],[UserDefaults objectForKey:@"userid"],totalStr,[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableId"],[UserDefaults objectForKey:@"TableNo"],flag];
    
    NSLog(@"Url:=>%@",urlString);
    
    [request setURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSData *requestData = [jsonString dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    [request setHTTPBody:requestData];
    
    NSError *error;
    NSURLResponse *response;
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    NSString *returnString=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    NSDictionary *FinalReplayData = [returnString JSONValue];
    
    NSLog(@"Reply:=>%@",FinalReplayData);
    NSLog(@"Success:=>%@",[FinalReplayData objectForKey:@"Success"]);
    
    if ([[NSString stringWithFormat:@"%@",[FinalReplayData objectForKey:@"Success"]] isEqualToString:@"True"])
    {
        [self.indicatorCart stopAnimating];
        
        [app_delegate.sk deleteWhere:[NSString stringWithFormat:@"roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]] forTable:@"AddProduct"];
        NSString *querystring1=[NSString stringWithFormat:@"select * from AddProduct where roomid=%@ and Tableno=%@",[UserDefaults objectForKey:@"RoomId"],[UserDefaults objectForKey:@"TableNo"]];
        app_delegate.CartItemData=[app_delegate.sk lookupAllForSQL:querystring1];
        
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
    }
    [self.indicatorCart stopAnimating];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
