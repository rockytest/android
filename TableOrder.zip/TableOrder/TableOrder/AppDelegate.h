//
//  AppDelegate.h
//  TableOrder
//
//  Created by macmini on 29/02/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "SKDatabase.h"
@class skdatabase;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    SKDatabase *sk;
}


@property (retain, nonatomic) UIColor *appColor;
@property(nonatomic,retain)NSArray *CartItemData;
@property(readonly)SKDatabase *sk;
@property (strong, nonatomic) UIWindow *window;

// object of navigation controller
@property(strong,nonatomic) UINavigationController *objNavigationController;


@end

