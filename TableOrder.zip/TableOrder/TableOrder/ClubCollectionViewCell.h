//
//  ClubCollectionViewCell.h
//  GameDayXtra
//
//  Created by macmin on 13/08/15.
//
//

#import <UIKit/UIKit.h>

@interface ClubCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UILabel *lblClubName;
@property(nonatomic,weak)IBOutlet UIImageView *imgClub;
@property(nonatomic,weak)IBOutlet UIView *BGWhite;
@end
