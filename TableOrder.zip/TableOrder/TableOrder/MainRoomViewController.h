//
//  MainRoomViewController.h
//  TableOrder
//
//  Created by Macmini on 11/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainRoomViewController : UIViewController<GlobalApiDelegate>
{
    int deleteTableTag;
    NSMutableArray *roomsArray;
    NSMutableArray *allRoomsArray;
    
    int selectedTableTag;
    
    // Progress HUD
    MBProgressHUD *HUD;

    int currentSelection;
}
@property (weak, nonatomic) IBOutlet UIScrollView *scrlTableRoom;
- (IBAction)btnRefresh:(id)sender;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicatorRooms;
@property (weak, nonatomic) IBOutlet UIScrollView *scrlRoom;

@end
