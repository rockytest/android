//
//  CategoriesTableViewCell.h
//  TableOrder
//
//  Created by macmini on 01/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoriesTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageViewForCategory;
@property (weak, nonatomic) IBOutlet UILabel *lblCategoryName;
@property (weak, nonatomic) IBOutlet UIImageView *imageViewForCart;

@end
