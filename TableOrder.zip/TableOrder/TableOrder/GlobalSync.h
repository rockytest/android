//
//  GlobalSync.h
//  Home Delivery
//
//  Created by Darshan Kunjadiya on 23/07/15.
//  Copyright (c) 2015 Darshan Kunjadiya. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "AppDelegate.h"


@protocol GlobalApiDelegate;

@interface GlobalSync : NSObject
{
    
}

+ (id)sharedData;


/********************* Login ***************************/
-(void)loginMethod :(NSDictionary *)aDictionary;

/********************* Register ***************************/
-(void)registerMethod :(NSDictionary *)aDictionary;

/********************* forgot password ***************************/
-(void)forgotPasswordMethod :(NSDictionary *)aDictionary;

/********************* get categories ***************************/
-(void)getCategoriesMethod :(NSDictionary *)aDictionary;

/********************* get products ***************************/
-(void)getProductsMethod :(NSDictionary *)aDictionary;

/********************* get Room ***************************/
-(void)getRoomMethod :(NSDictionary *)aDictionary;

/********************* Delete Transacation ***************************/
-(void)deleteTransacationMethod :(NSDictionary *)aDictionary;


/********************* get BookTable ***************************/
-(void)getBookTableMethod :(NSDictionary *)aDictionary;

@property (nonatomic,weak) id <GlobalApiDelegate> delegate;
@end

@protocol GlobalApiDelegate <NSObject>

@optional

/********************* Login ***************************/
-(void)loginData :(NSDictionary *)aLoginDict error:(NSError *)aError;

/********************* Register ***************************/
-(void)registerData :(NSDictionary *)aRegisterDict error:(NSError *)aError;

/********************* forgot password ***************************/
-(void)forgotPasswordData :(NSDictionary *)aForgotPasswordDict error:(NSError *)aError;


/********************* get categories ***************************/
-(void)getCategoriesData :(NSDictionary *)aGetCategoriesDict error:(NSError *)aError;

/********************* get products ***************************/
-(void)getProductsData :(NSDictionary *)aGetProductsDict error:(NSError *)aError;

/********************* get Room ***************************/
-(void)getRoomsData :(NSDictionary *)aGetRoomsDict error:(NSError *)aError;

/********************* Delete Transaction ***************************/
-(void)getDeleteTransData :(NSString *)aGetTransactionString error:(NSError *)aError;

/********************* get BookTable ***************************/
-(void)getBookTableData :(NSDictionary *)aGetBookTableDict error:(NSError *)aError;

@end
