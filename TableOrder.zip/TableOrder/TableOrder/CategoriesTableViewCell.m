//
//  CategoriesTableViewCell.m
//  TableOrder
//
//  Created by macmini on 01/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import "CategoriesTableViewCell.h"

@implementation CategoriesTableViewCell
@synthesize imageViewForCategory;
@synthesize lblCategoryName;
@synthesize imageViewForCart;

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
