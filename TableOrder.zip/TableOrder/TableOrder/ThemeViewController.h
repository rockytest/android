//
//  ThemeViewController.h
//  TableOrder
//
//  Created by Macmini on 16/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThemeViewController : UIViewController
- (IBAction)btnChangeColor:(id)sender;

@end
