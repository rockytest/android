//
//  CartViewController.h
//  TableOrder
//
//  Created by Macmini on 15/03/16.
//  Copyright © 2016 macmini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CartViewController : UIViewController<UITextFieldDelegate>
{
    float sum;
    int qty;
    
    IBOutlet UIView *MainAddtoCartView_potrait_ipad;
    IBOutlet UIView *innerAddtocartView_potrait_ipad;
    IBOutlet UILabel *Cartitem_name_potrait_ipad;
    IBOutlet UITextField *CartDetailQtyText_potrait_ipad;
    IBOutlet UITextField *CartDetailPriceText_potrait_ipad;
    IBOutlet UITextField *CartDetailDiscountText_potrait_ipad;
    IBOutlet UIButton *CartDetailSequence_potrait_ipad;
    IBOutlet UILabel *CartDetailTotalText_potrait_ipad;
    
    BOOL isAddtoCartClicked;
    int AddtoCartTag;
}

@property (weak, nonatomic) IBOutlet UILabel *lblTotalAmount;
- (IBAction)btnClose:(id)sender;
- (IBAction)btnRoom:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tblCart;
- (IBAction)btnSaveOrder:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *viewFooter;
@property (weak, nonatomic) IBOutlet UIView *viewFooterBG;
@property (weak, nonatomic) IBOutlet UIButton *refSaveOrder;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicatorCart;

@end
